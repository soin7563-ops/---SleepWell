package app.sleepwell.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.clickable
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import app.sleepwell.analysis.AnalysisDisplay
import app.sleepwell.analysis.AnalysisPresenter
import app.sleepwell.analysis.AnalysisRunner
import app.sleepwell.analysis.ChartPoint
import app.sleepwell.analysis.DirectInputForm
import app.sleepwell.analysis.DirectInputParser
import app.sleepwell.analysis.Gauge
import app.sleepwell.analysis.Reading
import app.sleepwell.analysis.ReadingKind
import app.sleepwell.analysis.ResultStore
import app.sleepwell.analysis.SavedSnapshot
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import app.sleepwell.analysis.ProfileStore
import app.sleepwell.analysis.NextNightModel
import app.sleepwell.analysis.SleepDataStore
import app.sleepwell.analysis.SurveyCsv
import app.sleepwell.analysis.SurveyDay
import app.sleepwell.analysis.SurveyStore
import app.sleepwell.analysis.Notice
import app.sleepwell.analysis.HealthConnectSleep
import androidx.health.connect.client.PermissionController
import app.sleepwell.analysis.Seg
import app.sleepwell.analysis.SegStyle
import app.sleepwell.health.AnalysisResult
import app.sleepwell.health.DirectInput
import app.sleepwell.health.DisplayZone
import app.sleepwell.health.HealthResult
import app.sleepwell.health.SleepRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

/*
 * 사용자 화면: 수면 분석 결과. (소빈 · 2026-09-25, 합의안 2절 ⑤~⑧)
 *
 * 흐름: CSV 선택 → (백그라운드) 채윤 파이프라인 → AnalysisResult → AnalysisPresenter 로 정리 → 화면
 *
 * - 채윤 파이프라인 호출은 AnalysisRunner 한 곳에서만 한다.
 * - 값은 임시 모델 결과라 확정값이 아니다 → 화면 맨 위에 "임시 모델" 표시.
 * - 권장 시각은 모델에 없어 "준비 중". futureS 는 채윤 코드가 임시 예측을 넣어서 "임시 예측"으로 표시.
 * - (2026-10-24) 권장 카드 → 「다음 수면 일정」 카드(ScheduleCard). 예상(모델·내 기록)과 권장을 나눠 보여준다.
 *   목표 기상이 없으면 "목표 기상 입력하기" → 실제 컨디션 입력 칸으로 스크롤.
 * - (2026-10) 날짜(밤) 선택: ◀ ▶ 와 달력으로 "○○ 밤"(그날 12:00 ~ 다음 날 12:00)을 골라 본다.
 *   처음에는 가장 최근 밤. "지금 상태"·예측은 가장 최근 밤에서만 보인다.
 *   가장 최근 밤은 업로드 때 계산한 결과(마지막 기록 기준 앞 7일)를 쓰고,
 *   지난 밤을 고르면 그 밤의 끝을 기준 시각으로 다시 계산한다(그 앞 7일). 고를 수 있는 밤 = 데이터 전체 범위. (2026-10)
 */

/** 계산 결과 + 그때 쓴 입력. 밤·시간대를 바꿀 때 같은 입력으로 화면만 다시 정리하기 위해 함께 둔다. */
private data class Computed(val result: AnalysisResult, val direct: DirectInput?, val condition: Int?, val survey: SurveyDay? = null)

private val COLOR_S = Color(0xFF3D6FB6)      // 수면 압력: 파랑
private val COLOR_C = Color(0xFFE8853A)      // 일주기 리듬: 주황
private val COLOR_P = Color(0xFF7B4FC9)      // 수면 성향: 보라
private val COLOR_SLEEP_BAND = Color(0x2E3D6FB6)       // (2026-10-24) 실제로 잔 시간: 연한 파란 바탕
private val COLOR_SLEEP_SWATCH = Color(0x663D6FB6)     // 설명 글 속 같은 색 네모
private val COLOR_PRED_BAR = Color(0xFF8A94A3)         // 예상: 회색 막대
private val COLOR_REC_BAR = Color(0xFF2E9D5B)          // 권장: 초록 막대
private val COLOR_MEANING = Color(0xFFFFF4CC)          // 해석 "무슨 뜻인가" 노란 바탕
private val COLOR_MANUAL_BAND = Color(0x297B4FC9)
private val COLOR_SOFT_BOX = Color(0xFFF3F4F7)       // 체크 설명·경향 문장 배경
private val COLOR_NOTE = Color(0xFF777777)
private val COLOR_SOFT_TEXT = Color(0xFF5F6673)     // (v7) 분석 설명 본문 — 연하게
private val COLOR_STRONG_TEXT = Color(0xFF1F2933)   // (v7) 강조 조각 — 진하게

/** (2026-10-27) CSV 직접 선택 안내 — 삼성 헬스 내보내기에는 파일이 많아서 */
/** (v7) 앱이 다시 앞으로 올 때마다 1씩 늘어나는 값 (MainActivity.onResume) — 날짜가 바뀌었으면 기록을 다시 읽는 데 씀 */
object AppResume { val tick = androidx.compose.runtime.mutableStateOf(0) }

private const val CSV_FILE_GUIDE = "삼성 헬스 내보내기 파일 중 com.samsung.health.sleep_stage…csv (이름에 'stage'가 있는 파일)를 골라 주세요."

/**
 * 시연용 합성(가짜) 데이터 — 실제 사람 기록 아님 (2026-10-24). 수면 + 같은 날짜의 설문(참여자 Test)을 한 번에 불러온다.
 * 이전 샘플(실제 팀원 기록)은 repo 공개 문제로 앱에서 뺐다. 실제 데이터 확인은 "CSV 파일 선택"으로.
 * 만든 코드: 프로젝트 폴더의 make_demo.py (다시 만들기: python make_demo.py app/src/main/assets)
 */
private data class DemoSet(val label: String, val sleep: String, val survey: String)
private val DEMOS = listOf(
    DemoSet("규칙적 30일", "demo_sleep_regular.csv", "demo_survey_regular.csv"),
    DemoSet("불규칙 30일", "demo_sleep_irregular.csv", "demo_survey_irregular.csv"),
    DemoSet("신규 5일", "demo_sleep_new.csv", "demo_survey_new.csv")
)

@Composable
fun AnalysisScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var loading by remember { mutableStateOf(false) }
    var sourceName by remember { mutableStateOf<String?>(null) }
    var display by remember { mutableStateOf<AnalysisDisplay?>(null) }
    var error by remember { mutableStateOf<Notice?>(null) }          // (2026-10-24) 이유 코드별 안내 카드
    var computed by remember { mutableStateOf<Computed?>(null) }
    var selectedNight by remember { mutableStateOf<Long?>(null) }   // null = 가장 최근 밤
    var pickMessage by remember { mutableStateOf<String?>(null) }
    var nightLoading by remember { mutableStateOf(false) }          // 지난 밤 다시 계산 중
    var nightError by remember { mutableStateOf<Notice?>(null) }    // 지난 날을 계산할 수 없을 때 이유
    val zone = UiZone.current                                        // 표시 시간대 (바꾸면 아래 LaunchedEffect 가 다시 정리)

    // ── 4단계 직접 입력 상태 ──
    var fileReady by remember { mutableStateOf(false) }          // 업로드한 파일이 캐시에 있는가
    var form by remember { mutableStateOf(DirectInputForm()) }
    var formErrors by remember { mutableStateOf<List<String>>(emptyList()) }
    var appliedInput by remember { mutableStateOf<DirectInput?>(null) }
    var appliedCondition by remember { mutableStateOf<Int?>(null) }
    var lastRecordEnd by remember { mutableStateOf<Long?>(null) }   // 업로드 기록의 마지막 기상

    val uploaded = File(context.cacheDir, "upload_sleep_stage.csv")
    val scroll = rememberScrollState()
    // (2026-10-24) 취침 전 설문은 앱 안에서 직접 입력 (실제 컨디션 입력 칸). 설문 CSV 올리기는 뺐다 —
    //  CSV 내보내기 파일은 서윤 언니 개인 보정 학습용. 지금 모델 계산에는 오늘 값만 필요하고, 그중 목표 기상만 쓰인다.
    var appliedSurvey by remember { mutableStateOf<SurveyDay?>(null) }
    // 합성 데이터 버튼: 그 데이터의 합성 설문으로 실제 컨디션 입력 칸을 미리 채운다 (분석이 끝나 마지막 기록을 안 뒤 한 번)
    var demoSurvey by remember { mutableStateOf<List<SurveyDay>>(emptyList()) }
    // (2026-10-24 팀장 답변) 입력한 설문은 폰 안 survey_log.csv 에 날짜별로 쌓는다 → 개인 보정 학습 데이터
    val surveyFile = remember { surveyLogFile(context) }
    var surveyNote by remember { mutableStateOf<String?>(null) }
    // (2026-10-24) 결과 저장 (폰 안 파일, 저장 기록 탭에서 조회)
    val storeFile = remember { savedResultsFile(context) }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    var formY by remember { mutableStateOf(0) }
    var conditionOpen by remember { mutableStateOf(false) }   // (v7) 실제 컨디션 입력 펼침 (처음엔 접힘)
    var appliedForm by remember { mutableStateOf(DirectInputForm()) }   // (v7) 마지막으로 반영한 입력 (요약 줄 "(반영 전)" 판단)

    // 캐시에 있는 파일 + 직접 입력으로 계산 (백그라운드)
    fun runAnalysis(direct: DirectInput?, condition: Int?, survey: SurveyDay? = null) {
        saveMessage = null
        loading = true
        error = null
        display = null
        computed = null
        pickMessage = null
        scope.launch {
            val result = withContext(Dispatchers.Default) {
                // (v6) 쌓인 설문의 피로도를 그날 일기에 붙이도록 새 모델 연결 쪽에 넘긴다 (합성 데이터 = 참여자 "Test")
                val who = if (sourceName?.startsWith("합성 데이터") == true) "Test" else "me"
                NextNightModel.surveyDays = try { SurveyStore.load(surveyFile).filter { it.participant == who } } catch (e: Exception) { emptyList() }
                AnalysisRunner.runFile(uploaded, direct, survey?.featureValues(SurveyCsv.SURVEY_ZONE) ?: emptyMap())
            }
            when (result) {
                is HealthResult.Success -> {
                    if (direct == null) lastRecordEnd = result.data.sleepRecords.maxOfOrNull { it.endMs }   // 업로드 직후 1회 기록
                    selectedNight = null                     // 새로 계산하면 가장 최근 밤부터
                    computed = Computed(result.data, direct, condition, survey)
                }
                else -> error = AnalysisPresenter.failureNotice(result)
            }
            loading = false
        }
    }

    // 업로드 직후 백그라운드에서 계산 (합의안 3-2). 새 파일이면 직접 입력은 비운다.
    fun analyze(name: String, copyTo: (File) -> Unit) {
        sourceName = name
        form = DirectInputForm(); appliedForm = DirectInputForm(); formErrors = emptyList(); appliedInput = null; appliedCondition = null; appliedSurvey = null; surveyNote = null; lastRecordEnd = null
        fileReady = try { copyTo(uploaded); true } catch (e: Exception) {
            error = Notice("파일을 읽지 못했어요", listOf(e.message ?: "알 수 없는 오류")); display = null; false
        }
        if (fileReady) runAnalysis(null, null)
    }

    // 입력이 바뀌면 다시 계산 (합의안 5-1 #3 "사용자 조건 변경 시 재계산")
    fun applyForm() {
        val parsed = DirectInputParser.parse(form, lastRecordEnd)
        formErrors = parsed.errors
        if (!parsed.ok) return
        appliedInput = parsed.input
        appliedCondition = form.condition
        appliedSurvey = parsed.survey
        conditionOpen = false                 // (v7) 반영하면 접고 요약 한 줄만
        appliedForm = form
        // 설문 항목(또는 목표 기상)을 넣었으면 그날 기록으로 쌓는다. 합성 데이터는 참여자 "Test" 로 구분
        surveyNote = parsed.survey?.let { sv ->
            val who = if (sourceName?.startsWith("합성 데이터") == true) "Test" else "me"
            try {
                val all = SurveyStore.save(surveyFile, sv.copy(participant = who))
                "${sv.date.substring(5).replace('-', '/')} 설문으로 저장했어요 · 쌓인 기록 ${all.count { it.participant == who }}일 (「저장 기록」 탭)"
            } catch (e: Exception) { "설문을 저장하지 못했어요: ${e.message}" }
        }
        runAnalysis(appliedInput, appliedCondition, appliedSurvey)
    }

    // ── (v6 2026-10-31) 수면 기록 보관 + 합치기: 과거 = 내보내기 CSV, 앞으로 = 헬스 커넥트 (analysis/SleepDataStore.kt) ──
    val dataDir = remember { File(context.filesDir, "sleep_data") }
    // (v6) 내 정보(프로필) — 새 모델의 목표 수면시간 출발점 (analysis/ProfileStore.kt)
    val profileFile = remember { File(context.filesDir, ProfileStore.FILE_NAME) }
    var profile by remember { mutableStateOf(NextNightModel.profile) }
    var profileSaved by remember { mutableStateOf(profileFile.isFile) }
    var storeMessage by remember { mutableStateOf<String?>(null) }
    var lastOpenDay by remember { mutableStateOf<java.time.LocalDate?>(null) }   // (v7) 마지막으로 기록을 읽은 날 (날짜 바뀜 감지)
    /** 보관한 기록(내보내기 + 헬스 커넥트)을 합쳐서 분석. prepare = 보관 전에 할 일(새 파일 저장 등) */
    fun analyzeStored(prepare: () -> Unit = {}) {
        scope.launch {
            val built = withContext(Dispatchers.IO) {
                try { prepare(); Result.success(SleepDataStore.buildMerged(dataDir)) } catch (e: Exception) { Result.failure<Pair<File, SleepDataStore.MergeInfo>?>(e) }
            }
            built.onSuccess { pair ->
                if (pair == null) return@onSuccess
                val (merged, info) = pair
                storeMessage = "내보내기 기록 ${info.archiveSessions}번 + 헬스 커넥트 새 기록 ${info.healthConnectAdded}번을 합쳐 분석해요"
                demoSurvey = emptyList()
                val name = when {
                    info.archiveSessions > 0 && info.healthConnectAdded > 0 -> "삼성 헬스 (내보내기 + 연동)"
                    info.archiveSessions > 0 -> "삼성 헬스 내보내기"
                    else -> "삼성 헬스 (헬스 커넥트)"
                }
                analyze(name) { dst -> merged.copyTo(dst, overwrite = true) }
            }.onFailure { e -> error = Notice("파일을 읽지 못했어요", listOf(e.message ?: "알 수 없는 오류")) }
        }
    }
    /** 고른 CSV 를 과거 기록(내보내기)으로 보관하고 분석 */
    fun keepArchive(uri: Uri) = analyzeStored {
        val tmp = File(context.cacheDir, "picked_sleep_stage.csv")
        copyUri(context, uri, tmp)
        SleepDataStore.saveArchive(dataDir, tmp)
        tmp.delete()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) keepArchive(uri)
    }
    // (2026-10-27) 삼성 헬스 내보내기 **폴더**를 고르면 그 안의 sleep_stage CSV 를 앱이 찾아 읽는다
    var folderMessage by remember { mutableStateOf<String?>(null) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree: Uri? ->
        if (tree == null) return@rememberLauncherForActivityResult
        folderMessage = null
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                try { SamsungExportFolder.findSleepStageCsv(context, tree) } catch (e: Exception) { null }
            }
            if (found == null) {
                folderMessage = "이 폴더에서 수면 단계 파일(com.samsung.health.sleep_stage…csv)을 찾지 못했어요. " +
                    "삼성 헬스 내보내기 폴더(com.samsung… 로 시작하는 CSV 들이 있는 폴더)를 골라 주세요."
            } else {
                folderMessage = "찾은 파일: ${found.name}"
                keepArchive(found.uri)
            }
        }
    }

    // ── (2026-10-27) 삼성 헬스 → 헬스 커넥트에서 바로 불러오기 (CSV 없이) ──
    var hcBusy by remember { mutableStateOf(false) }
    var showCsvGuide by remember { mutableStateOf(false) }
    var hcMessage by remember { mutableStateOf<String?>(null) }
    fun importFromHealthConnect() {
        hcBusy = true; hcMessage = null
        scope.launch {
            val res = withContext(Dispatchers.IO) {
                try { Result.success(HealthConnectSleep.readAsCsv(context)) } catch (e: Exception) { Result.failure<HealthConnectSleep.ImportResult>(e) }
            }
            res.onSuccess { r ->
                if (r.sessionCount == 0) {
                    hcMessage = "수면 기록을 찾지 못했어요. 삼성 헬스 → 설정 → 헬스 커넥트 기능이 허용돼 있는지 확인해 주세요."
                    if (SleepDataStore.hasArchive(dataDir)) analyzeStored()      // (v6) 보관한 내보내기 기록은 그대로 분석
                } else {
                    hcMessage = null   // (소빈 10/31) 파란 글씨는 기록이 없거나 문제가 있을 때만 띄운다
                    analyzeStored { SleepDataStore.saveHealthConnect(dataDir, r.csv) }   // (v6) 내보내기 기록과 합쳐서
                }
            }.onFailure { e ->
                hcMessage = if (e is SecurityException) "수면 읽기 권한이 없어요. 다시 \"삼성 헬스에서 불러오기\"를 눌러 허용해 주세요."
                    else "헬스 커넥트에서 읽지 못했어요: ${e.message ?: e::class.java.simpleName}"
            }
            hcBusy = false
        }
    }
    val hcPermissionLauncher = rememberLauncherForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
        if (granted.containsAll(HealthConnectSleep.PERMISSIONS)) importFromHealthConnect()
        else hcMessage = "수면 읽기를 허용해야 삼성 헬스 기록을 불러올 수 있어요."
    }
    fun connectHealthConnect() {
        when (HealthConnectSleep.availability(context)) {
            HealthConnectSleep.Availability.UNAVAILABLE ->
                hcMessage = "이 폰에서는 헬스 커넥트를 쓸 수 없어요. 안드로이드 13 이하는 Play 스토어에서 '헬스 커넥트(Health Connect)'를 설치해 주세요."
            HealthConnectSleep.Availability.NEEDS_UPDATE ->
                hcMessage = "헬스 커넥트 업데이트가 필요해요. Play 스토어에서 업데이트한 뒤 다시 눌러 주세요."
            HealthConnectSleep.Availability.AVAILABLE -> scope.launch {
                val ok = try { HealthConnectSleep.hasPermission(context) } catch (e: Exception) { false }
                if (ok) importFromHealthConnect() else hcPermissionLauncher.launch(HealthConnectSleep.PERMISSIONS)
            }
        }
    }
    // 이미 허용했으면 앱을 열 때 자동으로 불러온다 (권한 창은 버튼을 누를 때만)
    LaunchedEffect(Unit) {
        if (display != null || loading || fileReady) return@LaunchedEffect
        val ok = HealthConnectSleep.availability(context) == HealthConnectSleep.Availability.AVAILABLE &&
            (try { HealthConnectSleep.hasPermission(context) } catch (e: Exception) { false })
        if (ok) importFromHealthConnect()                          // 보관한 내보내기 기록과 합쳐서 분석
        else if (SleepDataStore.hasAny(dataDir)) analyzeStored()   // (v6) 연동이 안 돼도 보관한 기록이 있으면 그걸로
        lastOpenDay = java.time.LocalDate.now(java.time.ZoneId.of("Asia/Seoul"))
    }
    // (v7) 앱을 켜 둔 채 날짜가 바뀐 뒤 다시 화면으로 돌아오면(백그라운드 → 앞) 헬스 커넥트를 다시 읽는다
    //  → 가장 최근 날짜가 하루 넘어가고, 어제의 권장은 지난 날짜(예상 vs 실제)로, 오늘 날짜에 새 권장이 나온다.
    //  같은 날 안에서는 다시 읽지 않는다 (입력 중인 실제 컨디션 입력 칸이 지워지지 않게)
    val resumeTick = AppResume.tick.value
    LaunchedEffect(resumeTick) {
        val today = java.time.LocalDate.now(java.time.ZoneId.of("Asia/Seoul"))
        val last = lastOpenDay ?: return@LaunchedEffect
        if (today == last || loading || hcBusy) return@LaunchedEffect
        if (sourceName?.startsWith("합성 데이터") == true) return@LaunchedEffect          // 시연 중엔 그대로
        lastOpenDay = today
        val ok = HealthConnectSleep.availability(context) == HealthConnectSleep.Availability.AVAILABLE &&
            (try { HealthConnectSleep.hasPermission(context) } catch (e: Exception) { false })
        if (ok) importFromHealthConnect() else if (SleepDataStore.hasAny(dataDir)) analyzeStored()
    }

    // 지난 날 계산 결과 저장 (같은 날을 다시 고르면 다시 계산하지 않음). 새로 계산(파일·직접 입력)하면 비운다.
    val nightCache = remember(computed) { mutableMapOf<Long, HealthResult<AnalysisResult>>() }

    // (2026-10-24 A안) 고른 날·표시 시간대가 바뀌면:
    //  - 가장 최근 날 → 업로드 때 계산한 결과(마지막 기상 기준 앞 7일)를 그대로 정리
    //  - 지난 날     → 그날 아침 기상 시각(없으면 낮 12시)을 기준 시각으로 한 번 다시 계산
    //                  + 그날 설문 기록에 알람이 있으면 목표 기상으로 넣어 권장까지 계산
    LaunchedEffect(computed, selectedNight, zone) {
        val c = computed ?: return@LaunchedEffect
        val base = c.result
        val latestRef = base.scHistory.lastOrNull()?.timestampMs ?: base.calculationTimeMs
        val dataStart = listOfNotNull(base.sleepRecords.minOfOrNull { it.startMs }, base.scHistory.firstOrNull()?.timestampMs).minOrNull()
        val days = AnalysisPresenter.days(base.sleepRecords, c.direct, latestRef, dataStart)
        val sel = selectedNight?.let { k -> AnalysisPresenter.dayStartOf(k).let { st -> days.firstOrNull { it.startMs == st } } }
        nightError = null
        nightLoading = false
        if (sel == null || sel.isLatest) {
            display = withContext(Dispatchers.Default) {
                AnalysisPresenter.build(base, null, direct = c.direct, condition = c.condition, latestRefMs = latestRef, dataStartMs = dataStart, survey = c.survey)
            }
            return@LaunchedEffect
        }
        nightLoading = true
        // 그날 설문 알람 → 목표 기상 (설문 날짜 = 기준 시각 − 6시간의 날짜 = 그날 저녁 설문). 합성 데이터는 참여자 "Test"
        val who = if (sourceName?.startsWith("합성 데이터") == true) "Test" else "me"
        val allSurveys = withContext(Dispatchers.IO) {
            try { SurveyStore.load(surveyFile) } catch (e: Exception) { emptyList<SurveyDay>() }
        }.filter { it.participant == who }
        NextNightModel.surveyDays = allSurveys                          // (v6) 피로도 → 그날 일기
        val daySurvey = allSurveys.firstOrNull { it.date == SurveyCsv.surveyDateFor(sel.basisMs) }
        val alarm = daySurvey?.alarmTime
        val target = alarm?.let { a ->
            Regex("""^(\d{1,2}):(\d{2})$""").matchEntire(a.trim())?.let { m ->
                DirectInputParser.nextOccurrence(sel.basisMs, m.groupValues[1].toInt(), m.groupValues[2].toInt(), DirectInputParser.MIN_WAKE_GAP_MS)
            }
        }
        val pastDirect = DirectInput(c.direct?.sleepStartMs, c.direct?.sleepEndMs, target, null)
            .takeIf { it.sleepStartMs != null || it.targetWakeMs != null }
        // (임시) 수면시간 목표를 그날 기상까지의 기록으로 — 엔진은 파일 전체로 세서 미래 기록이 섞임 (AnalysisRunner.sleepTargetUntil 참고)
        val sleepTarget = AnalysisRunner.sleepTargetUntil(base.sleepRecords, sel.basisMs)
        val res = nightCache[sel.startMs] ?: withContext(Dispatchers.Default) {
            AnalysisRunner.runFileAt(uploaded, pastDirect, sel.basisMs, sleepTarget,
                daySurvey?.featureValues(SurveyCsv.SURVEY_ZONE) ?: emptyMap())
        }.also { nightCache[sel.startMs] = it }
        display = withContext(Dispatchers.Default) {
            if (res is HealthResult.Success)
                AnalysisPresenter.build(res.data, sel.startMs, direct = pastDirect, latestRefMs = latestRef, dataStartMs = dataStart)
            else
                // 계산이 안 되는 날: 날짜 고르기는 계속 쓸 수 있게 날짜 목록만 업로드 결과로 만든다
                AnalysisPresenter.build(base, sel.startMs, direct = c.direct, latestRefMs = latestRef, dataStartMs = dataStart)
        }
        if (res !is HealthResult.Success) {
            nightError = AnalysisPresenter.failureNotice(res, pastDay = true)
        }
        nightLoading = false
    }

    // (2026-10-24) 합성 데이터: 그 데이터의 설문(마지막 기록 기준 날짜, 없으면 그 전 가장 가까운 날)으로 실제 컨디션 입력 칸을 채우고 한 번 반영
    LaunchedEffect(lastRecordEnd, demoSurvey) {
        val last = lastRecordEnd ?: return@LaunchedEffect
        if (loading || demoSurvey.isEmpty()) return@LaunchedEffect
        val day = SurveyCsv.surveyDateFor(last)
        val sv = demoSurvey.filter { it.date <= day }.maxByOrNull { it.date } ?: demoSurvey.maxByOrNull { it.date }
        demoSurvey = emptyList()                       // 한 번만
        if (sv == null) return@LaunchedEffect
        fun n(v: Double?) = v?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: ""
        form = form.copy(
            targetWakeText = sv.alarmTime ?: "",
            condition = sv.fatigue,
            caffeineMgText = if (sv.caffeineUsed == false) "0" else n(sv.caffeineMg),
            lastCaffeineText = sv.lastCaffeine ?: "",
            napMinText = n(sv.napMinutes), napEndText = sv.napEnd ?: "",
            exerciseMinText = n(sv.exerciseMinutes), exerciseIntensity = sv.exerciseIntensity
        )
        pickMessage = null
        applyForm()
    }

    // 달력에서 날짜 고르기. (A안) 고른 날짜 = 그날 아침 기상 기준
    fun openDatePicker(d: AnalysisDisplay) {
        val nights = d.nights
        val cur = d.night ?: return
        if (nights.isEmpty()) return
        val tz = zone.tz
        val c = Calendar.getInstance(tz).apply { timeInMillis = cur.startMs }
        // (v7 11/05) 달력 대신 연/월/일 돌림판 (저장 기록 탭과 같은 방식)
        val dlg = android.app.DatePickerDialog(context, android.R.style.Theme_Holo_Light_Dialog_NoActionBar, { _, y, m, day ->
            val pick = Calendar.getInstance(tz).apply { clear(); set(y, m, day, 0, 0, 0) }.timeInMillis
            val target = nights.firstOrNull { it.startMs == pick }
            if (target != null) { selectedNight = target.startMs; pickMessage = null }
            else pickMessage = "그 날짜는 계산 범위 밖이에요. ${nights.first().label} ~ ${nights.last().label} 중에서 골라 주세요."
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
        // 달력은 기기 시간대로 날짜를 그리므로, 고를 수 있는 범위를 같은 날짜의 기기 시간대 시각으로 바꿔서 건다
        fun deviceDay(ms: Long, endOfDay: Boolean): Long {
            val src = Calendar.getInstance(tz).apply { timeInMillis = ms }
            return Calendar.getInstance().apply {
                clear()
                set(src.get(Calendar.YEAR), src.get(Calendar.MONTH), src.get(Calendar.DAY_OF_MONTH),
                    if (endOfDay) 23 else 0, if (endOfDay) 59 else 0, 0)
            }.timeInMillis
        }
        dlg.datePicker.minDate = deviceDay(nights.first().startMs, false)
        dlg.datePicker.maxDate = deviceDay(nights.last().startMs, true)
        @Suppress("DEPRECATION")
        dlg.datePicker.calendarViewShown = false
        dlg.datePicker.spinnersShown = true
        dlg.show()
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp)
    ) {
        Text("수면 분석", style = MaterialTheme.typography.headlineSmall)
        Text(
            "삼성 헬스 수면 기록으로 수면 압력과 일주기 리듬을 계산해 보여줘요.",
            style = MaterialTheme.typography.bodySmall
        )

        // (2026-10-27) 기본 = 삼성 헬스(헬스 커넥트)에서 바로 불러오기. 처음 한 번 허용하면 다음부터 자동
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { connectHealthConnect() },
            enabled = !loading && !hcBusy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (hcBusy) "삼성 헬스에서 불러오는 중…" else "삼성 헬스 연결하기") }
        Text(
            "처음 한 번 연동을 허락하면, 다음부터는 자동으로 불러와요. (최근 30일)",
            style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE
        )
        hcMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF3D6FB6)) }

        Spacer(Modifier.height(6.dp))
        OutlinedButton(
            onClick = { showCsvGuide = true },          // (2026-10-27) 안내 창 → "폴더 고르기"(기본) 또는 "파일 직접 고르기"
            enabled = !loading,
            modifier = Modifier.fillMaxWidth()
        ) { Text("데이터 불러오기") }
        folderMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF3D6FB6)) }
        if (showCsvGuide) {
            AlertDialog(
                onDismissRequest = { showCsvGuide = false },
                title = { Text("불러올 폴더를 선택해 주세요.") },
                text = {
                    Column {
                        // 긴 파일 이름은 통째로 다음 줄로 넘어가 첫 줄 끝이 크게 비었다 → 글자 사이에 줄바꿈 가능 표시(폭 0 공백)를 넣고,
                        // 줄을 고르게 나누는 기본 방식 대신 한 줄을 끝까지 채우는 방식(LineBreak.Simple)으로 → 한 문단처럼 보이게
                        Text(
                            "'다운로드 > Samsung Health' 폴더를 고르면, 그 안에서 수면 단계 파일(" + breakAnywhere("com.samsung.health.sleep_stage…csv") + ")을 찾아 읽어요.",
                            style = MaterialTheme.typography.bodyMedium.copy(lineBreak = LineBreak.Simple)
                        )
                        Spacer(Modifier.height(8.dp))
                        listOf(
                            "Samsung Health 폴더로 들어간 뒤, 아래 '이 폴더 사용'을 눌러 주세요.",
                            "파일 하나를 직접 고르고 싶으면, 아래 '파일 직접 고르기'를 선택해 주세요."
                        ).forEach { line ->
                            Row {
                                Text("·  ", style = MaterialTheme.typography.bodySmall, color = COLOR_NOTE)
                                Text(line, style = MaterialTheme.typography.bodySmall.copy(lineBreak = LineBreak.Simple), color = COLOR_NOTE)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showCsvGuide = false
                        // 폴더 고르는 화면(안드로이드 기본 화면)에는 글을 넣을 수 없어서, 열리는 동안 같은 안내를 잠깐 띄운다
                        android.widget.Toast.makeText(context, "삼성 헬스 내보내기 폴더로 들어가서 '이 폴더 사용'을 눌러 주세요", android.widget.Toast.LENGTH_LONG).show()
                        folderPicker.launch(null)
                    }) { Text("폴더 고르기") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            showCsvGuide = false
                            android.widget.Toast.makeText(context, "이름에 'stage'가 있는 파일을 골라 주세요", android.widget.Toast.LENGTH_LONG).show()
                            picker.launch(arrayOf("text/*", "text/csv", "text/comma-separated-values", "application/octet-stream"))
                        }) { Text("파일 직접 고르기") }
                        TextButton(onClick = { showCsvGuide = false }) { Text("취소") }
                    }
                }
            )
        }

        Spacer(Modifier.height(6.dp))
        Text("시연용 합성 데이터 (가짜 기록 · 실제 컨디션 입력 칸도 합성 설문으로 채워져요)", style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DEMOS.forEach { demo ->
                OutlinedButton(
                    onClick = {
                        // 합성 설문을 먼저 넣어 두면, 분석이 끝난 뒤 실제 컨디션 입력 칸이 자동으로 채워진다
                        val parsed = try { context.assets.open(demo.survey).use { SurveyCsv.parse(it.readBytes().toString(Charsets.UTF_8)) } } catch (e: Exception) { null }
                        demoSurvey = parsed?.days ?: emptyList()
                        // 합성 설문 전체를 "그동안 쌓인 설문 기록"(참여자 Test)으로 넣어 둔다 → 지난 날짜를 골라도 그날 알람으로 권장 계산
                        try { SurveyStore.saveAll(surveyFile, demoSurvey.map { it.copy(participant = "Test") }) } catch (e: Exception) { }
                        analyze("합성 데이터: ${demo.label}") { dst -> copyAsset(context, demo.sleep, dst) }
                    },
                    enabled = !loading,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) { Text(demo.label, style = MaterialTheme.typography.labelMedium) }
            }
        }

        if (fileReady) {
            Spacer(Modifier.height(16.dp))
            // (소빈 10/31) 「내 정보 입력」과 「실제 컨디션 입력」을 한 묶음(외곽선)으로 — 사용자가 넣는 값 두 가지가 짝으로 보이게
            Column(
                Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFD5DAE2), RoundedCornerShape(18.dp))
                    .padding(8.dp)
            ) {
                ProfileCard(profile = profile, saved = profileSaved, enabled = !loading) { p ->
                    try { ProfileStore.save(profileFile, p); profileSaved = true } catch (e: Exception) { }
                    profile = p
                    NextNightModel.profile = p
                    runAnalysis(appliedInput, appliedCondition, appliedSurvey)      // 바뀐 프로필로 예상·권장 다시 계산
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.onGloballyPositioned { formY = it.positionInParent().y.toInt() }) {
                    DirectInputCard(
                        lastRecordEnd = lastRecordEnd,
                        form = form,
                        onChange = { form = it },
                        errors = formErrors,
                        enabled = !loading,
                        recommendationReady = computed?.result?.recommendation != null,
                        savedNote = surveyNote,
                        onApply = { applyForm() },
                        open = conditionOpen,
                        appliedForm = appliedForm,
                        onToggle = { conditionOpen = !conditionOpen }
                    )
                }
            }
        }

        if (loading) {
            Spacer(Modifier.height(16.dp))
            Row {
                CircularProgressIndicator(modifier = Modifier.height(24.dp).width(24.dp))
                Text("  분석 중… (${sourceName ?: ""})", style = MaterialTheme.typography.bodyMedium)
            }
        }

        error?.let { n ->
            Spacer(Modifier.height(12.dp))
            InfoCard(n.title, n.lines, Color(0xFFFDE7E9))      // 문장은 AnalysisPresenter.failureNotice (이유 코드 기준)
        }

        display?.let { d ->
            Spacer(Modifier.height(16.dp))
            NightSelector(
                d = d,
                zone = zone,
                message = pickMessage,
                onSelect = { selectedNight = it; pickMessage = null },
                onPickDate = { openDatePicker(d) }
            )
            Spacer(Modifier.height(12.dp))
            when {
                nightLoading -> Row {
                    CircularProgressIndicator(modifier = Modifier.height(24.dp).width(24.dp))
                    Text("  이 날 기준으로 계산 중…", style = MaterialTheme.typography.bodyMedium)
                }
                nightError != null -> nightError?.let { n -> InfoCard(n.title, n.lines, Color(0xFFFDE7E9)) }
                else -> AnalysisContent(
                    d, sourceName ?: "", zone,
                    onAskTargetWake = { conditionOpen = true; scope.launch { scroll.animateScrollTo(formY) } },
                    onSave = {
                        // (v7) 결과 글자 + 계산 재료(SavedSnapshot)를 같이 저장 → 「저장 기록」 달력에서 그때 화면 그대로 다시 보기
                        val c = computed
                        val past = d.schedule?.isPast == true
                        val night = d.night
                        val who = if (sourceName?.startsWith("합성 데이터") == true) "Test" else "me"
                        // 그날 입력: 가장 최근 날 = 지금 반영한 설문 / 지난 날 = 그날 쌓인 설문 (알람은 일정 카드에 있어서 빼고 요약)
                        val daySurvey = if (!past) appliedSurvey
                            else night?.basisMs?.let { b -> NextNightModel.surveyDays.firstOrNull { it.date == SurveyCsv.surveyDateFor(b) } }
                        val sv = daySurvey?.let { s0 ->
                            listOfNotNull(s0.alarmTime?.let { "알람 $it" }, s0.summary(includeAlarm = false).takeIf { s0.hasItems() })
                                .joinToString(" · ").ifBlank { null }
                        }
                        val r = ResultStore.fromDisplay(d, sourceName ?: "", sv, profileText = ProfileStore.summary(NextNightModel.profile))
                        saveMessage = if (r == null || c == null) "저장할 일정이 없어요."
                            else try {
                                val (_, replaced) = ResultStore.saveReplacing(storeFile, r)
                                replaced.filter { it != r.savedAtMs }.forEach { old -> try { SavedSnapshot.delete(context.filesDir, old) } catch (e: Exception) { } }
                                try {
                                    SavedSnapshot.save(
                                        context.filesDir, r.savedAtMs, uploaded, c.direct, c.condition, c.survey,
                                        NextNightModel.surveyDays, NextNightModel.profile,
                                        dayStartMs = if (past) night?.startMs else null,
                                        dayBasisMs = if (past) night?.basisMs else null,
                                        participant = who
                                    )
                                } catch (e: Exception) { }
                                "저장했어요 · 「저장 기록」 달력의 ${r.dayDate.substring(5).replace('-', '/')}에 표시돼요."
                            } catch (e: Exception) { "저장하지 못했어요: ${e.message}" }
                    },
                    saveMessage = saveMessage
                )
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}

/**
 * 날짜 고르기 (2026-10-24 A안): ◀ [10/20(화) 기상] ▶ + 달력 + (지난 날이면) 가장 최근으로
 */
@Composable
@Suppress("UNUSED_PARAMETER")   // zone: 시간대를 바꾸면 다시 그리게 하려고 받는다
private fun NightSelector(
    d: AnalysisDisplay,
    zone: DisplayZone,
    message: String?,
    onSelect: (Long) -> Unit,
    onPickDate: () -> Unit
) {
    val night = d.night ?: return
    val idx = d.nights.indexOfFirst { it.startMs == night.startMs }
    val prev = d.nights.getOrNull(idx - 1)
    val next = d.nights.getOrNull(idx + 1)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { prev?.let { onSelect(it.startMs) } }, enabled = prev != null) { Text("◀") }
                Text(
                    night.label, style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f), textAlign = TextAlign.Center
                )
                OutlinedButton(onClick = { next?.let { onSelect(it.startMs) } }, enabled = next != null) { Text("▶") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = onPickDate) { Text("날짜 고르기") }
                if (!night.isLatest) TextButton(onClick = { onSelect(d.nights.last().startMs) }) { Text("가장 최근으로") }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
internal fun AnalysisContent(      // (v7) 저장 기록 결과 화면에서도 같은 모양으로 쓰려고 internal
    d: AnalysisDisplay, sourceName: String, zone: DisplayZone, onAskTargetWake: () -> Unit,
    /** (2026-10-24) "이 결과 저장" — 일정 카드 아래 */
    onSave: (() -> Unit)? = null,
    saveMessage: String? = null,
    /** (v7) 저장 기록 화면: 분석(위쪽 안내 + 분석 카드)만 / 일정 카드만 나눠 그릴 수 있게 */
    showAnalysis: Boolean = true,
    showSchedule: Boolean = true
) {
    val latest = d.night?.isLatest != false
    if (showAnalysis) {
    // 위쪽 안내: 임시 모델 · 데이터 · (기록이 적을 때만) 주의 한 줄
    SoftBox {
        Text(
            (if (d.isTemporaryModel) "임시 모델로 계산했어요 · " else "") + "데이터: $sourceName",
            style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE
        )
        val caution = when {
            d.night?.isPartial == true -> "기록이 시작된 직후라 수면 압력이 실제와 다를 수 있어요."
            d.windowSleepCount < 3 -> "앞 7일 기록이 ${d.windowSleepCount}번뿐이라, 기록 없는 날이 깨어 있던 것으로 계산돼 수면 압력이 높게 나올 수 있어요."
            else -> null
        }
        caution?.let { Text("⚠ $it", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A5A00)) }
    }
    if (latest && d.inputNotes.isNotEmpty() && showSchedule) {
        Spacer(Modifier.height(8.dp))
        InfoCard("입력 반영", d.inputNotes, Color(0xFFE8F0FB))
    }

    // ── 분석 (2026-10-24 A안): 지난밤 수면 → 그래프 → 해석 ①②③ ──────────
    //   지시서 Ⅲ-3 "현재 및 다음 날 수면압력 변화 · 일주기 리듬과 수면 성향 그래프 · 수치의 의미 설명"
    //   (v7 11/05) 정보가 많아 피로하지 않게: 설명 본문은 연한 글씨, 색 있는 용어·숫자·노란 '뜻' 부분만 진하게
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("지난밤 수면 분석", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            val ls = d.lastSleep
            if (ls != null) {
                // (v7 11/05) 제목 바로 아래 왼쪽 세로선과 함께 두 줄 (잔 시각 · 잔 시간·단계)
                Column(
                    Modifier
                        .fillMaxWidth()
                        .drawBehind { drawLine(Color(0xFFA9BCDB), Offset(1.5f.dp.toPx(), 0f), Offset(1.5f.dp.toPx(), size.height), 3.dp.toPx()) }
                        .padding(start = 12.dp, top = 1.dp, bottom = 1.dp)
                ) {
                    Text(ls.rangeText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Text(ls.detailText, style = MaterialTheme.typography.bodySmall, color = COLOR_SOFT_TEXT)
                }
            } else {
                Text(
                    "이 날은 3시간 넘게 잔 기록이 없어(워치 미착용 등) ${AnalysisPresenter.dayTime(d.referenceMs)} 기준으로 계산했어요.",
                    style = MaterialTheme.typography.bodySmall, color = COLOR_NOTE
                )
            }
            Spacer(Modifier.height(10.dp))
            ConceptBox {
                Text(buildAnnotatedString {
                    append("✓ "); withStyle(SpanStyle(color = COLOR_S, fontWeight = FontWeight.Bold)) { append("수면 압력") }
                    append("은 깨어 있던 시간만큼 쌓이는 피로를 나타내요.")
                }, style = MaterialTheme.typography.bodySmall, color = COLOR_SOFT_TEXT)
                Text(buildAnnotatedString {
                    append("✓ "); withStyle(SpanStyle(color = COLOR_C, fontWeight = FontWeight.Bold)) { append("일주기 리듬") }
                    append("은 하루 주기로 바뀌는 몸의 리듬을 나타내요.")
                }, style = MaterialTheme.typography.bodySmall, color = COLOR_SOFT_TEXT)
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = COLOR_STRONG_TEXT)) {
                        append("→ 둘을 합친 ")
                        withStyle(SpanStyle(color = COLOR_P)) { append("잠들기 쉬운 정도") }
                        append("가 클수록 잠들기 쉬워요.")
                    }
                }, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Legend("수면 압력", COLOR_S)
                Legend("일주기 리듬", COLOR_C)
                Legend("잠들기 쉬운 정도", COLOR_P)
            }
            Spacer(Modifier.height(6.dp))
            if (d.history.isEmpty()) {
                Text("표시할 값이 없어요.", style = MaterialTheme.typography.bodySmall)
            } else {
                Canvas(Modifier.fillMaxWidth().height(240.dp)) { drawAnalysisChart(d) }
            }
            // 그래프 표시 설명: 글자 설명 대신 그림 + 이름 (2026-10-24 소빈)
            Spacer(Modifier.height(4.dp))
            if (d.future.isNotEmpty()) Text(
                "점선 = " + (if (d.basisIsWake) "일어난 뒤" else "기준 시각부터") + " 계속 깨어 있다고 가정한 예측 (임시)",
                style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE
            )
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = COLOR_SLEEP_SWATCH)) { append("■") }; append(" 실제로 잔 시간")
                if (d.manualSleep != null) { append("  ·  "); withStyle(SpanStyle(color = COLOR_MANUAL_BAND.copy(alpha = 0.6f))) { append("■") }; append(" 기록 보완") }
            }, style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)
            if (d.gapBands.isNotEmpty()) Text("빗금 = 기록 없음 (깨어 있던 것으로 계산돼 실제보다 높게 보여요)", style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)

            // 해석 ①②③ — 숫자(무슨 일) + 노란 바탕(무슨 뜻)
            d.analysisLines.forEachIndexed { i, l ->
                Spacer(Modifier.height(12.dp))
                Text("${"①②③④⑤".getOrElse(i) { '·' }} ${l.title}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(2.dp))
                Text(segText(l.segs), style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp), color = COLOR_SOFT_TEXT)
            }
            if (d.schedule != null && showSchedule) {
                Spacer(Modifier.height(10.dp))
                Text("예상·권장 취침 시각은 아래 「수면 일정」에서 확인할 수 있어요.", style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)
            }
        }
    }
    }

    // ── 예측 및 권장: 그날 밤 수면 일정 ──
    if (showSchedule) d.schedule?.let {
        if (showAnalysis) Spacer(Modifier.height(16.dp))
        ScheduleCard(it, onAskTargetWake)
        // 결과 저장 — (v7) 지난 날짜(예상 vs 실제)에서도 저장 (흐름: 분석 → 예상·권장 → 저장·조회)
        if (onSave != null) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("이 결과 저장") }
            saveMessage?.let { m -> Text(m, style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE) }
        }
    }

    if (!latest || !showAnalysis || !showSchedule) return     // 최근 기록 목록은 수면 분석 화면의 가장 최근 날에서만

    // (v7 11/05) 최근 수면 기록 — 제목만, 누르면 펼침
    var showRecent by remember { mutableStateOf(false) }
    Spacer(Modifier.height(16.dp))
    Card(Modifier.fillMaxWidth().clickable { showRecent = !showRecent }) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("최근 수면 기록", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text(if (showRecent) "▾" else "›", color = COLOR_NOTE)
            }
            if (showRecent) {
                if (d.recentSleeps.isEmpty()) Text("기록이 없어요.", style = MaterialTheme.typography.bodySmall)
                d.recentSleeps.forEach { SleepRecordRow(it, zone) }
            }
        }
    }
}

/** 해석 문장 조각 → 색·굵기·노란 바탕 (2026-10-24) */
private fun segText(segs: List<Seg>) = buildAnnotatedString {
    segs.forEach { sg ->
        val st = when (sg.style) {
            SegStyle.PLAIN -> null
            SegStyle.BOLD -> SpanStyle(fontWeight = FontWeight.Bold, color = COLOR_STRONG_TEXT)
            SegStyle.S -> SpanStyle(color = COLOR_S, fontWeight = FontWeight.Bold)
            SegStyle.C -> SpanStyle(color = COLOR_C, fontWeight = FontWeight.Bold)
            SegStyle.MEANING -> SpanStyle(background = COLOR_MEANING, color = COLOR_STRONG_TEXT)
            SegStyle.MEANING_BOLD -> SpanStyle(background = COLOR_MEANING, fontWeight = FontWeight.Bold, color = COLOR_STRONG_TEXT)
            SegStyle.SLEEP_SWATCH -> SpanStyle(color = COLOR_SLEEP_SWATCH)
        }
        if (st == null) append(sg.text) else withStyle(st) { append(sg.text) }
    }
}

@Composable
@Suppress("UNUSED_PARAMETER")   // zone: 시간대를 바꾸면 이 줄도 다시 그리게 하려고 받는다 (글자는 AnalysisPresenter 가 표시 시간대로 만든다)
private fun SleepRecordRow(r: SleepRecord, zone: DisplayZone) {
    val total = r.totalSleepMin
    val parts = listOf("LIGHT", "DEEP", "REM").joinToString(" · ") { k ->
        val m = r.stageSummary[k] ?: 0.0
        val pct = if (total > 0) m * 100 / total else 0.0
        "$k ${pct.toInt()}%"
    }
    Spacer(Modifier.height(6.dp))
    Text(
        "${AnalysisPresenter.dayTime(r.startMs)} → ${AnalysisPresenter.hhmm(r.endMs)}",
        style = MaterialTheme.typography.labelLarge
    )
    Text(
        "잔 시간 ${(total / 60).toInt()}시간 ${(total % 60).toInt()}분 · $parts",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
private fun Legend(label: String, color: Color) {
    Row {
        Canvas(Modifier.width(14.dp).height(10.dp)) {
            drawLine(color, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 3.dp.toPx())
        }
        Text(" $label", style = MaterialTheme.typography.labelSmall)
    }
}

/** (v7 11/05) 개념 설명 상자 — 연한 보라 바탕 + 얇은 외곽선 (분석 카드 안에서 따로 보이게, 진하지 않게) */
@Composable
private fun ConceptBox(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFFFBFAFE), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFE6E2F2), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) { content() }
}

/** 연회색 둥근 상자 (체크 설명·경향 문장) */
@Composable
private fun SoftBox(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = COLOR_SOFT_BOX), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) { content() }
    }
}

private fun colorOf(k: ReadingKind) = when (k) { ReadingKind.S -> COLOR_S; ReadingKind.C -> COLOR_C; ReadingKind.P -> COLOR_P }

/** 지금 상태의 값 하나: 제목·큰 값 → (막대) → 설명 → (세부) → (작은 주석) */
@Composable
private fun ReadingBlock(r: Reading) {
    val color = colorOf(r.kind)
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(r.title, style = MaterialTheme.typography.labelLarge, color = color)
        Text(r.value, style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
    }
    r.gauge?.let { GaugeBar(it, color) }
    if (r.meaning.isNotBlank()) Text(r.meaning, style = MaterialTheme.typography.bodySmall)
    r.details.forEach { Text("· $it", style = MaterialTheme.typography.bodySmall) }
    r.note?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE) }
}

/** 범위 막대: 연한 색 → 진한 색, 지금 값 위치에 검은 표시 */
@Composable
private fun GaugeBar(g: Gauge, color: Color) {
    Spacer(Modifier.height(4.dp))
    Canvas(Modifier.fillMaxWidth().height(14.dp)) {
        val barH = 8.dp.toPx(); val top = (size.height - barH) / 2
        drawRoundRect(
            Brush.horizontalGradient(listOf(color.copy(alpha = 0.15f), color)),
            Offset(0f, top), Size(size.width, barH), CornerRadius(barH / 2)
        )
        val f = ((g.value - g.min) / (g.max - g.min)).coerceIn(0.0, 1.0).toFloat()
        val mx = (size.width * f).coerceIn(2.dp.toPx(), size.width - 2.dp.toPx())
        drawRoundRect(Color(0xFF1F2933), Offset(mx - 2.dp.toPx(), 0f), Size(4.dp.toPx(), size.height), CornerRadius(2.dp.toPx()))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(g.leftLabel, style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)
        Text(g.rightLabel, style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)
    }
}

@Composable
private fun DirectInputCard(
    lastRecordEnd: Long?,
    form: DirectInputForm,
    onChange: (DirectInputForm) -> Unit,
    errors: List<String>,
    enabled: Boolean,
    /** 권장 엔진이 붙어 있는가 (없으면 목표 기상도 "계산에 반영 안 됨 · 준비 중") */
    recommendationReady: Boolean,
    /** 설문 누적 저장 결과 한 줄 */
    savedNote: String?,
    onApply: () -> Unit,
    /** (v7 11/05) 접고 펴기 — 처음엔 접힘(요약 한 줄), "입력 반영"하면 다시 접힘 */
    open: Boolean = true,
    onToggle: () -> Unit = {},
    /** (v7) 마지막으로 반영한 입력 — 지금 칸과 다르면 요약 줄에 "(반영 전)" */
    appliedForm: DirectInputForm = form
) {
    // (2026-10-24) 직접 입력 → 「실제 컨디션 입력」 + 취침 전 설문 항목. 마지막 기록이 "오늘 아침"이라는 보장이 없어서 "오늘 밤"이라 부르지 않는다.
    //  계산에 실제로 쓰이는지 항목마다 꼬리표로 밝힌다: ✓ 계산에 반영 / 계산에 반영 안 됨(기록만) / 준비 중
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("실제 컨디션 입력 (선택)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = onToggle) { Text(if (open) "닫기" else "수정") }
            }
            // (v7 11/05) 기준 날짜를 한 줄로: 그날(마지막 기록의 기상일) 하루의 피로도·그날 아침 개운함, 그날 밤 → 다음 날 아침 기상에 쓰인다.
            //  날짜 = 설문이 저장되는 날짜와 같은 규칙(SurveyCsv.surveyDateFor). 접혀 있을 때는 넣은 값 요약을 같은 줄에
            val filled = conditionSummary(form)
            // 기준 날짜 = 설문이 실제로 저장될 날짜 (기록 보완을 넣으면 보완한 기상일), 없으면 마지막 기록의 기상일
            val baseDate = remember(form, lastRecordEnd) {
                (try { DirectInputParser.parse(form, lastRecordEnd).input?.sleepEndMs } catch (e: Exception) { null })
                    ?.takeIf { lastRecordEnd == null || it > lastRecordEnd }
                    ?.let { SurveyCsv.surveyDateFor(it) } ?: lastRecordEnd?.let { SurveyCsv.surveyDateFor(it) }
            }
            Text(buildAnnotatedString {
                if (baseDate != null) {
                    withStyle(SpanStyle(color = Color(0xFF3D6FB6), fontWeight = FontWeight.Bold)) { append(baseDate) }
                    append(if (open) " 기준이에요." else " 기준 · ")
                }
                if (!open) {
                    append(filled ?: "아직 입력 안 함")
                    if (form != appliedForm) withStyle(SpanStyle(color = Color(0xFF8A5A00))) { append(" (반영 전)") }
                }
            }, style = MaterialTheme.typography.bodySmall)

            if (open) {
            // ── 목표 기상 ──
            Spacer(Modifier.height(10.dp))
            FieldTitle("목표 기상 (알람)", if (recommendationReady) StatusTag.USED else StatusTag.PREPARING)
            PickerField(null, form.targetWakeText, Modifier.fillMaxWidth(),
                onOpen = { pickTime(context, form.targetWakeText, 7, 0) { onChange(form.copy(targetWakeText = it)) } },
                onClear = { onChange(form.copy(targetWakeText = "")) })

            // ── 피로도 ──
            Spacer(Modifier.height(10.dp))
            FieldTitle("오늘 하루 피로도", StatusTag.ACCUMULATES)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                (1..7).forEach { v ->
                    FilterChip(
                        selected = form.condition == v,
                        onClick = { onChange(form.copy(condition = if (form.condition == v) null else v)) },
                        label = { Text("$v") }
                    )
                }
            }
            Hint("1 매우 맑음 → 7 매우 피곤함")

            // ── 개운함 (v6) ── 그날 아침 일어났을 때. 개운함 4 이상 + 피로도 4 이하 = "잘 잔 밤" → 5번 넘게 쌓이면 목표 수면시간이 나에게 맞춰짐
            Spacer(Modifier.height(10.dp))
            FieldTitle("아침 개운함", StatusTag.ACCUMULATES)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                (1..5).forEach { v ->
                    FilterChip(
                        selected = form.rested == v,
                        onClick = { onChange(form.copy(rested = if (form.rested == v) null else v)) },
                        label = { Text("$v") }
                    )
                }
            }
            Hint("1 전혀 개운하지 않음 → 5 매우 개운함")

            // ── 카페인 ──
            Spacer(Modifier.height(10.dp))
            FieldTitle("카페인", StatusTag.RECORD_ONLY)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("양 (mg)", form.caffeineMgText, Modifier.weight(1f)) { onChange(form.copy(caffeineMgText = it)) }
                PickerField("마지막 섭취", form.lastCaffeineText, Modifier.weight(1f),
                    onOpen = { pickTime(context, form.lastCaffeineText, 15, 0) { onChange(form.copy(lastCaffeineText = it)) } },
                    onClear = { onChange(form.copy(lastCaffeineText = "")) })
            }
            Hint("아메리카노 한 잔 ≈ 100~150mg (안 마셨으면 0)")

            // ── 낮잠 ──
            Spacer(Modifier.height(10.dp))
            FieldTitle("낮잠", StatusTag.RECORD_ONLY)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("시간 (분)", form.napMinText, Modifier.weight(1f)) { onChange(form.copy(napMinText = it)) }
                PickerField("끝난 시각", form.napEndText, Modifier.weight(1f),
                    onOpen = { pickTime(context, form.napEndText, 15, 0) { onChange(form.copy(napEndText = it)) } },
                    onClear = { onChange(form.copy(napEndText = "")) })
            }

            // ── 운동 ──
            Spacer(Modifier.height(10.dp))
            FieldTitle("운동", StatusTag.RECORD_ONLY)
            NumberField("시간 (분)", form.exerciseMinText, Modifier.fillMaxWidth()) { onChange(form.copy(exerciseMinText = it)) }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("none" to "안 함", "light" to "가벼움", "moderate" to "보통", "vigorous" to "격함").forEach { (k, w) ->
                    FilterChip(
                        selected = form.exerciseIntensity == k,
                        onClick = { onChange(form.copy(exerciseIntensity = if (form.exerciseIntensity == k) null else k)) },
                        label = { Text(w) }
                    )
                }
            }

            // ── 기록 보완 (워치 기록이 빠졌을 때만) ──
            Spacer(Modifier.height(14.dp))
            FieldTitle("기록 보완 (선택)", StatusTag.USED)
            Hint("업로드한 데이터 이후의 시간을 넣으면, 그 시각까지 이어서 계산해요.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = form.bedText, onValueChange = { onChange(form.copy(bedText = it)) },
                    label = { Text("취침") }, placeholder = { Text("2026-09-15 23:30") }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = form.wakeText, onValueChange = { onChange(form.copy(wakeText = it)) },
                    label = { Text("기상") }, placeholder = { Text("2026-09-16 07:10") }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }

            if (errors.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                errors.forEach { Text("· $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onApply, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                Text("입력 반영해서 다시 분석")
            }
            // 저장 안내("10/24 설문으로 저장했어요 …")는 펼쳤을 때만 — 접혀 있을 땐 요약 줄만
            savedNote?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF3D6FB6)) }
            }
        }
    }
}

/** (v7) 실제 컨디션 입력 요약 한 줄: "알람 08:00 · 피로도 2 · 개운함 4 · 카페인 150mg" (아무것도 없으면 null) */
private fun conditionSummary(f: DirectInputForm): String? = listOfNotNull(
    f.targetWakeText.trim().takeIf { it.isNotEmpty() }?.let { "알람 $it" },
    f.condition?.let { "피로도 $it" },
    f.rested?.let { "개운함 $it" },
    f.caffeineMgText.trim().takeIf { it.isNotEmpty() }?.let { "카페인 ${it}mg" },
    f.napMinText.trim().toDoubleOrNull()?.let { "낮잠 ${minutesText(it.toInt())}" },
    f.exerciseMinText.trim().takeIf { it.isNotEmpty() }?.let { "운동 ${it}분" },
    if (f.bedText.isNotBlank() || f.wakeText.isNotBlank()) "기록 보완" else null
).joinToString(" · ").ifBlank { null }

/**
 * 내 정보 카드 (v6 → v7 11/05) — 나이대·성별·하루 활동량·희망 수면시간. 모두 선택 (처음엔 아무것도 안 고른 상태, 다시 누르면 취소).
 *  - 희망 수면시간 = 새 엔진(서윤 11/01)의 목표 수면시간 출발점. 고르지 않으면 위에서 고른 항목의 집단 평균(NHANES)
 *  - 평소 취침·기상은 워치 기록으로 자동이라 받지 않는다. 저장하면 폰 안 profile.properties 에 남고 다시 계산한다.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfileCard(
    profile: NextNightModel.ModelProfile,
    @Suppress("UNUSED_PARAMETER") saved: Boolean,
    enabled: Boolean,
    onSave: (NextNightModel.ModelProfile) -> Unit
) {
    var editing by remember { mutableStateOf(false) }
    var draft by remember(profile) { mutableStateOf(profile) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("내 정보 입력 (선택)", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = { editing = !editing; draft = profile }, enabled = enabled) { Text(if (editing) "닫기" else "수정") }
            }
            Text(ProfileStore.summary(if (editing) draft else profile), style = MaterialTheme.typography.bodySmall)
            if (editing) {
                Spacer(Modifier.height(8.dp))
                // (v7 11/05) 칩은 줄마다 같은 너비로 꽉 채움 (줄이 넘어가도 오른쪽이 비지 않게)
                Text("나이대", style = MaterialTheme.typography.labelLarge)
                ChipGrid(ProfileStore.AGE_BANDS, 4, { "${it}세" }, { draft.ageBand == it }) { a ->
                    draft = draft.copy(ageBand = if (draft.ageBand == a) null else a)
                }
                Spacer(Modifier.height(4.dp))
                Text("성별", style = MaterialTheme.typography.labelLarge)
                ChipGrid(ProfileStore.SEXES, 2, { it.second }, { draft.sex == it.first }) { (k, _) ->
                    draft = draft.copy(sex = if (draft.sex == k) null else k)
                }
                Spacer(Modifier.height(4.dp))
                Text("하루 활동량 (걷기·운동 등 몸을 움직인 시간)", style = MaterialTheme.typography.labelLarge)
                ChipGrid(ProfileStore.ACTIVITY, 3, { it.second }, { (_, w) -> draft.activityMinutes?.let { ProfileStore.activityLabel(it) } == w }) { (m, w) ->
                    val on = draft.activityMinutes?.let { ProfileStore.activityLabel(it) } == w
                    draft = draft.copy(activityMinutes = if (on) null else m)
                }
                Spacer(Modifier.height(4.dp))
                Text("희망 수면시간", style = MaterialTheme.typography.labelLarge)
                ChipGrid(ProfileStore.DESIRED, 3, { ProfileStore.hm(it) }, { draft.desiredSleepMinutes == it }) { m ->
                    draft = draft.copy(desiredSleepMinutes = if (draft.desiredSleepMinutes == m) null else m)
                }
                Hint("고르지 않으면 평균(${ProfileStore.hm(NextNightModel.populationAverageMinutes(draft))})으로 계산해요.")
                Spacer(Modifier.height(6.dp))
                Button(onClick = { editing = false; onSave(draft) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                    Text("저장하고 다시 계산")
                }
            }
        }
    }
}

/**
 * (v7 11/05) 칩을 perRow 개씩 줄마다 같은 너비로 꽉 채운다. 마지막 줄은 남은 칩끼리 나눠 채워서 오른쪽에 빈자리가 남지 않는다.
 */
@Composable
private fun <T> ChipGrid(items: List<T>, perRow: Int, label: (T) -> String, selected: (T) -> Boolean, onClick: (T) -> Unit) {
    Column {
        items.chunked(perRow).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { t ->
                    FilterChip(
                        selected = selected(t), onClick = { onClick(t) },
                        label = { Text(label(t), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, maxLines = 1) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

/** 입력 항목이 계산에 실제로 쓰이는지 (2026-10-24, 작업 지시서 "개발 완료/개발 중 구분") */
private enum class StatusTag(val text: String, val fg: Color, val bg: Color) {
    USED("✓ 계산에 반영", Color(0xFF1E6B3D), Color(0xFFE6F4EA)),
    RECORD_ONLY("계산에 반영 안 됨 · 기록으로 쌓임", Color(0xFF6B4A00), Color(0xFFFFF4DC)),
    PREPARING("준비 중 · 권장 계산 연결 전", Color(0xFF5A5F6B), Color(0xFFEDEFF2)),
    ACCUMULATES("✓ 쌓이면 목표 수면시간에 반영", Color(0xFF1E6B3D), Color(0xFFE6F4EA))
}

@Composable
private fun FieldTitle(title: String, tag: StatusTag) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
        Card(colors = CardDefaults.cardColors(containerColor = tag.bg)) {
            Text(tag.text, style = MaterialTheme.typography.labelSmall, color = tag.fg,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
        }
    }
}

@Composable
private fun Hint(text: String) = Text(text, style = MaterialTheme.typography.labelSmall, color = COLOR_NOTE)

@Composable
private fun NumberField(label: String, value: String, modifier: Modifier, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onValue, label = { Text(label) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

/**
 * (v7 11/05) 누르면 시·분 돌림판(드래그로 고르기)이 열리는 칸. 직접 타자로 넣지 않는다.
 * 모양은 옆의 직접 입력 칸(OutlinedTextField)과 똑같이 — 같은 칸을 읽기 전용으로 그리고 위에 누르는 영역을 덮는다.
 * 값이 있으면 오른쪽 ✕ 로 비울 수 있다. label 이 null 이면 칸 안 이름 없이 "눌러서 선택"만.
 */
@Composable
private fun PickerField(
    label: String?, value: String, modifier: Modifier, display: String = value,
    onOpen: () -> Unit, onClear: () -> Unit
) {
    Box(modifier) {
        OutlinedTextField(
            value = if (value.isBlank()) "" else display, onValueChange = {}, readOnly = true, singleLine = true,
            label = label?.let { { Text(it) } },
            placeholder = { Text("눌러서 선택") },
            trailingIcon = if (value.isNotBlank()) ({ Text("✕", color = COLOR_NOTE) }) else null,
            modifier = Modifier.fillMaxWidth()
        )
        // 칸 전체 = 돌림판 열기 (위에 덮어서 키보드가 뜨지 않게)
        Box(Modifier.matchParentSize().padding(top = 8.dp).clickable(onClick = onOpen))
        // 오른쪽 ✕ 자리 = 지우기 (맨 위)
        if (value.isNotBlank()) Box(
            Modifier.align(Alignment.CenterEnd).padding(top = 8.dp).size(48.dp).clickable(onClick = onClear)
        )
    }
}

/** 30 → "30분", 90 → "1시간 30분" */
private fun minutesText(m: Int): String = when { m < 60 -> "${m}분"; m % 60 == 0 -> "${m / 60}시간"; else -> "${m / 60}시간 ${m % 60}분" }

/**
 * 알람 앱처럼 시·분을 고르는 창 (2026-10-24). 고른 값은 "HH:mm" 으로 칸에 들어가고,
 * 날짜는 DirectInputParser 가 기준 시각 다음에 오는 그 시각으로 정한다.
 * 칸에 이미 "07:30" 이나 "2026-09-16 07:30" 이 있으면 그 시각에서 시작한다.
 */
private fun pickTime(context: Context, current: String, defH: Int, defM: Int, onPick: (String) -> Unit) {
    val m = Regex("""(\d{1,2}):(\d{2})\s*$""").find(current.trim())
    val h0 = m?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 0..23 } ?: defH
    val m0 = m?.groupValues?.get(2)?.toIntOrNull()?.takeIf { it in 0..59 } ?: defM
    // (v7 11/05) 시계 모양 대신 돌림판(드래그) — 저장 기록 탭 날짜 고르기와 같은 방식
    android.app.TimePickerDialog(context, android.R.style.Theme_Holo_Light_Dialog_NoActionBar, { _, h, mi ->
        onPick(String.format(java.util.Locale.US, "%02d:%02d", h, mi))
    }, h0, m0, true).show()
}

@Composable
private fun InfoCard(title: String, lines: List<String>, bg: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = bg), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            lines.forEach { Text("· $it", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 그래프
// ─────────────────────────────────────────────────────────────
private fun DrawScope.drawAnalysisChart(d: AnalysisDisplay) {
    // (2026-09-26) 그래프 안 표시 추가: "지금 → 예측", "잠", ▲(일주기 리듬 꼭대기), ↑졸림/↓개운함, 기록 없음 빗금, 날짜 눈금
    val leftPad = 30.dp.toPx()
    val topPad = 18.dp.toPx()        // "지금" 표시 자리
    val bottomPad = 16.dp.toPx()
    val plotW = size.width - leftPad
    val plotH = size.height - bottomPad - topPad
    val plotBottom = topPad + plotH

    val all = d.history + d.future
    // (2026-10) 가로 범위 = 고른 밤 (12:00 ~ 다음 날 12:00). 밤 정보가 없으면 예전처럼 데이터 범위.
    val startMs = if (d.graphStartMs > 0) d.graphStartMs else d.night?.startMs ?: d.history.first().timeMs
    val endMs = if (d.graphEndMs > 0) d.graphEndMs else d.night?.endMs ?: maxOf(all.last().timeMs, d.referenceMs + 1)
    val span = (endMs - startMs).coerceAtLeast(1L).toFloat()

    val values = all.flatMap { listOf(it.s, it.c, it.propensity) }
    val lo = (values.min() - 0.05).toFloat()
    val hi = (values.max() + 0.05).toFloat()
    val range = (hi - lo).coerceAtLeast(0.1f)

    fun x(ms: Long) = leftPad + plotW * (ms - startMs) / span
    fun y(v: Double) = topPad + plotH - plotH * (v.toFloat() - lo) / range
    fun text(s: String, px: Float, py: Float, color: String = "#666666", sizeSp: Float = 9f, bold: Boolean = false,
             align: android.graphics.Paint.Align = android.graphics.Paint.Align.LEFT) =
        drawIntoCanvas { c -> c.nativeCanvas.drawText(s, px, py, chartPaint(density, color, sizeSp, bold, align)) }

    // 기록 없음 (빗금) — 하루 넘게 수면 기록이 없어 '깨어 있음'으로 계산된 구간
    d.gapBands.forEach { g ->
        val xs = x(g.startMs.coerceIn(startMs, endMs)); val xe = x(g.endMs.coerceIn(startMs, endMs))
        if (xe - xs > 4f) {
            clipRect(xs, topPad, xe, plotBottom) {
                val gap = 7.dp.toPx()
                var k = xs - plotH
                while (k < xe) {
                    drawLine(Color(0x33808A96), Offset(k, plotBottom), Offset(k + plotH, topPad), 1.dp.toPx())
                    k += gap
                }
            }
            text("기록 없음", (xs + xe) / 2, plotBottom - 4.dp.toPx(), align = android.graphics.Paint.Align.CENTER)
        }
    }

    // 잔 시간 배경 + "잠"
    fun band(s0: Long, e0: Long, color: Color) {
        val xs = x(s0.coerceIn(startMs, endMs)); val xe = x(e0.coerceIn(startMs, endMs))
        if (xe > xs) {
            drawRect(color, Offset(xs, topPad), Size(xe - xs, plotH))
        }
    }
    d.manualSleep?.let { band(it.startMs, it.endMs, COLOR_MANUAL_BAND) }   // 직접 입력한 수면은 연보라
    d.sleepBands.forEach { band(it.startMs, it.endMs, COLOR_SLEEP_BAND) }   // 실제로 잔 시간 = 연한 파란 바탕

    // 가로 눈금 (0, 0.5, 1 중 범위 안에 있는 것)
    listOf(0.0, 0.5, 1.0).filter { it.toFloat() in lo..hi }.forEach { v ->
        val yy = y(v)
        drawLine(Color(0x22000000), Offset(leftPad, yy), Offset(size.width, yy), 1f)
        text(AnalysisPresenter.fmt(v), 2f, yy + 4.dp.toPx())
    }

    // 세로 눈금: 표시 시간대 기준 3시간마다 선, 6시간마다 시각 글자. 자정에는 날짜를 함께 쓴다.
    // (2026-10) 하루(24시간) 그래프로 바뀌어 12시간 → 3시간 간격. 시간대는 화면에서 고른 표시 시간대.
    val step = 3 * 3_600_000L
    val offset = app.sleepwell.health.DisplaySettings.zone.tz.getOffset(startMs).toLong()
    var t = Math.floorDiv(startMs + offset + step - 1, step) * step - offset
    while (t <= endMs) {
        val px = x(t)
        val localHour = (Math.floorMod(t + offset, 24 * 3_600_000L) / 3_600_000L).toInt()
        val midnight = localHour == 0
        drawLine(Color(if (midnight) 0x22000000 else 0x0D000000), Offset(px, topPad), Offset(px, plotBottom), 1f)
        if (localHour % 6 == 0) {
            val label = if (midnight) AnalysisPresenter.dayOnly(t) else "${localHour}시"
            val align = when {
                px < leftPad + 12.dp.toPx() -> android.graphics.Paint.Align.LEFT
                px > size.width - 12.dp.toPx() -> android.graphics.Paint.Align.RIGHT
                else -> android.graphics.Paint.Align.CENTER
            }
            text(label, px, size.height - 2.dp.toPx(), align = align)
        }
        t += step
    }


    // 선
    val solid = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
    val solidP = Stroke(width = 2.6f.dp.toPx(), cap = StrokeCap.Round)
    fun dashed(w: Float) = Stroke(width = w, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f))
    fun line(points: List<ChartPoint>, pick: (ChartPoint) -> Double, color: Color, style: Stroke) {
        if (points.isEmpty()) return
        val path = Path()
        points.forEachIndexed { i, p ->
            if (i == 0) path.moveTo(x(p.timeMs), y(pick(p))) else path.lineTo(x(p.timeMs), y(pick(p)))
        }
        drawPath(path, color, style = style)
    }
    line(d.history, { it.c }, COLOR_C, solid)
    line(d.history, { it.s }, COLOR_S, solid)
    line(d.history, { it.propensity }, COLOR_P, solidP)
    line(d.future, { it.c }, COLOR_C.copy(alpha = 0.7f), dashed(2.dp.toPx()))
    line(d.future, { it.s }, COLOR_S.copy(alpha = 0.7f), dashed(2.dp.toPx()))
    line(d.future, { it.propensity }, COLOR_P.copy(alpha = 0.7f), dashed(2.6f.dp.toPx()))

    // ▲ 일주기 리듬 꼭대기 (하루 중 몸이 가장 잠을 원하는 때) + ② (해설 문장 번호, 첫 ▲ 에만)
    val cMax = all.maxOf { it.c }
    var numbered = false
    for (i in 1 until all.size - 1) {
        val p = all[i]
        if (p.c >= all[i - 1].c && p.c > all[i + 1].c && p.c > cMax * 0.9) {
            val px = x(p.timeMs); val py = y(p.c); val r = 4.dp.toPx()
            val tri = Path().apply { moveTo(px - r, py - r - 2f); lineTo(px + r, py - r - 2f); lineTo(px, py - 1f); close() }
            drawPath(tri, COLOR_C)
            if (!numbered) { text("②", px + r + 2f, py - r, "#C9651F", 9f, true); numbered = true }
        }
    }

    // (2026-10-24 A안) ① 지난밤 잠든 때 (수면 압력 선 위)
    d.marks.onsetMs?.takeIf { it in startMs..endMs }?.let { ms ->
        d.history.minByOrNull { kotlin.math.abs(it.timeMs - ms) }?.let { p ->
            text("①", x(p.timeMs) + 4.dp.toPx(), y(p.s) - 4.dp.toPx(), "#3D6FB6", 9f, true)
        }
    }
    // ③ 지난밤 잠들 때만큼 피로가 다시 쌓이는 때 (수면 압력 예측선 위 점)
    d.marks.reachMs?.let { ms ->
        d.future.minByOrNull { kotlin.math.abs(it.timeMs - ms) }?.let { p ->
            val px = x(p.timeMs); val py = y(p.s)
            drawCircle(COLOR_S, 3.5f.dp.toPx(), Offset(px, py))
            text("③", px - 12.dp.toPx(), py - 5.dp.toPx(), "#3D6FB6", 9f, true)
        }
    }

    // (v7 11/05) 예상·권장 막대는 그래프에서 뺐다 (그래프 선과 관계없는 값이라) → 카드 아래 한 줄로 「수면 일정」 안내

    // 기준 시각 (세로선) — "기상" (기상 기록이 없는 날은 "기준")
    if (d.referenceMs !in startMs..endMs) return
    val rx = x(d.referenceMs)
    drawLine(Color(0x99000000), Offset(rx, topPad), Offset(rx, plotBottom), 1.5f)
    val pillW = 30.dp.toPx(); val pillH = 14.dp.toPx()
    drawRoundRect(Color(0xFF1F2933), Offset(rx - pillW / 2, 1.dp.toPx()), Size(pillW, pillH), CornerRadius(pillH / 2))
    text(if (d.basisIsWake) "기상" else "기준", rx, 1.dp.toPx() + 10.5f.dp.toPx(), "#FFFFFF", 9f, true, android.graphics.Paint.Align.CENTER)
}

private fun chartPaint(
    density: Float,
    colorHex: String = "#666666",
    sizeSp: Float = 9f,
    bold: Boolean = false,
    align: android.graphics.Paint.Align = android.graphics.Paint.Align.LEFT
) = android.graphics.Paint().apply {
    color = android.graphics.Color.parseColor(colorHex)
    textSize = sizeSp * density
    isFakeBoldText = bold
    textAlign = align
    isAntiAlias = true
}

// ─────────────────────────────────────────────────────────────
// 파일 복사 (파이프라인이 지금 File 을 받기 때문. 채윤이 InputStream 입력으로 바꾸면 불필요해짐)
// ─────────────────────────────────────────────────────────────
/** 긴 영문(파일 이름 등)을 아무 글자 사이에서나 줄바꿈할 수 있게 폭 0 공백을 끼운다 (보이는 글자는 그대로) */
private fun breakAnywhere(text: String): String = text.toList().joinToString("\u200B")

private fun copyUri(context: Context, uri: Uri, dst: File) {
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalArgumentException("선택한 파일을 열 수 없습니다.")
    input.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
}

private fun copyAsset(context: Context, name: String, dst: File) {
    context.assets.open(name).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
}
