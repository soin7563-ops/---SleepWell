package app.sleepwell.analysis

import java.io.File
import java.util.Properties

/*
 * 내 정보(프로필) 저장 (소빈 · 2026-10-31, 통합 v6)
 *
 * 서윤 새 모델이 쓰는 프로필 중 사용자가 정하는 3가지만 받는다.
 *  - 나이대 · 성별 · 하루 활동량 → 집단 평균 수면시간(NHANES)을 골라 목표 수면시간의 출발점으로 씀 (7~9시간 안)
 *  - 평소 취침·기상은 워치 기록 최근 14밤 중간값으로 자동 (NextNightModel.userProfile)
 *  - 희망 수면시간은 엔진의 예상·권장 계산에 안 쓰여서(연구용 비교값) 받지 않고 기본값
 * 앱 전용 폴더의 profile.properties 한 파일. 서버로 보내지 않는다. Android 없이 시험할 수 있게 File 만 받는다.
 */
object ProfileStore {

    const val FILE_NAME = "profile.properties"

    /** 엔진이 아는 나이대 (UserModelEngine.normalizeAgeBand) */
    val AGE_BANDS = listOf("18-29", "30-44", "45-59", "60-80")

    /** 화면 표시 이름 → 엔진 값 (female / male / any) */
    val SEXES = listOf("female" to "여성", "male" to "남성", "any" to "선택 안 함")

    /**
     * 하루 활동량 구간 → 엔진에 넘길 대표 분 (엔진 구간: 30분 미만 low · 90분 미만 medium · 그 이상 high)
     */
    val ACTIVITY = listOf(15 to "30분 미만", 60 to "30분~1시간 30분", 120 to "1시간 30분 이상")

    fun load(file: File): NextNightModel.ModelProfile? {
        if (!file.isFile) return null
        return try {
            val p = Properties().apply { file.inputStream().use { load(it) } }
            val base = NextNightModel.ModelProfile()
            NextNightModel.ModelProfile(
                ageBand = p.getProperty("ageBand")?.takeIf { it in AGE_BANDS } ?: base.ageBand,
                sex = p.getProperty("sex")?.takeIf { s -> SEXES.any { it.first == s } } ?: base.sex,
                activityMinutes = p.getProperty("activityMinutes")?.toIntOrNull()?.coerceIn(0, 1440) ?: base.activityMinutes,
                desiredSleepMinutes = base.desiredSleepMinutes
            )
        } catch (e: Exception) { null }
    }

    fun save(file: File, profile: NextNightModel.ModelProfile) {
        val p = Properties().apply {
            setProperty("ageBand", profile.ageBand)
            setProperty("sex", profile.sex)
            setProperty("activityMinutes", profile.activityMinutes.toString())
        }
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.outputStream().use { p.store(it, "SleepWell profile") }
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }

    /** 화면 한 줄 요약: "18-29 · 선택 안 함 · 활동 30분~1시간 30분" */
    fun summary(p: NextNightModel.ModelProfile): String =
        "${p.ageBand}세 · ${SEXES.firstOrNull { it.first == p.sex }?.second ?: p.sex} · 활동 ${activityLabel(p.activityMinutes)}"

    fun activityLabel(min: Int): String = when {
        min < 30 -> ACTIVITY[0].second
        min < 90 -> ACTIVITY[1].second
        else -> ACTIVITY[2].second
    }
}
