package app.sleepwell.analysis

import java.io.File
import java.util.Properties

/*
 * 내 정보(프로필) 저장 (소빈 · 2026-10-31, 통합 v6)
 *
 * 서윤 새 모델이 쓰는 프로필 중 사용자가 정하는 4가지 (전부 선택 — 고르지 않으면 null)
 *  - (v7 11/05) 희망 수면시간 = 목표 수면시간의 출발점 (서윤 11/01 엔진). 고르지 않으면 나이대·성별·활동량의
 *    집단 평균 수면시간(NHANES)으로 채움 (NextNightModel.effectiveDesiredMinutes) → 고른 항목까지만 반영
 *  - 평소 취침·기상은 워치 기록 최근 14밤 중간값으로 자동 (NextNightModel.userProfile)
 * 앱 전용 폴더의 profile.properties 한 파일. 서버로 보내지 않는다. Android 없이 시험할 수 있게 File 만 받는다.
 */
object ProfileStore {

    const val FILE_NAME = "profile.properties"

    /** 엔진이 아는 나이대 (UserModelEngine.normalizeAgeBand) */
    val AGE_BANDS = listOf("18-29", "30-44", "45-59", "60-80")

    /** 화면 표시 이름 → 엔진 값. 고르지 않으면 null (엔진에는 any) */
    val SEXES = listOf("female" to "여성", "male" to "남성")

    /**
     * 하루 활동량 구간 → 엔진에 넘길 대표 분 (엔진 구간: 30분 미만 low · 90분 미만 medium · 그 이상 high)
     */
    val ACTIVITY = listOf(15 to "30분 미만", 60 to "30~90분", 120 to "90분 이상")   // (v7) 칩 한 줄에 들어가게 짧게

    /** (v7) 희망 수면시간 칩 (분). 고르지 않으면 집단 평균 — 엔진 범위(성인 7~9시간)와 같다 */
    val DESIRED = listOf(420, 450, 480, 510, 540)

    /** (v7) 모든 항목은 고르지 않아도 된다 — 비어 있거나 모르는 값은 null(선택 안 함). 예전 파일의 sex=any 도 null */
    fun load(file: File): NextNightModel.ModelProfile? {
        if (!file.isFile) return null
        return try {
            val p = Properties().apply { file.inputStream().use { load(it) } }
            NextNightModel.ModelProfile(
                ageBand = p.getProperty("ageBand")?.takeIf { it in AGE_BANDS },
                sex = p.getProperty("sex")?.takeIf { s -> SEXES.any { it.first == s } },
                activityMinutes = p.getProperty("activityMinutes")?.toIntOrNull()?.coerceIn(0, 1440),
                desiredSleepMinutes = p.getProperty("desiredSleepMinutes")?.toIntOrNull()?.takeIf { it in DESIRED }
            )
        } catch (e: Exception) { null }
    }

    fun save(file: File, profile: NextNightModel.ModelProfile) {
        val p = Properties().apply {
            profile.ageBand?.let { setProperty("ageBand", it) }
            profile.sex?.let { setProperty("sex", it) }
            profile.activityMinutes?.let { setProperty("activityMinutes", it.toString()) }
            profile.desiredSleepMinutes?.let { setProperty("desiredSleepMinutes", it.toString()) }
        }
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.outputStream().use { p.store(it, "SleepWell profile") }
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
    }

    /** 화면 한 줄 요약: "18-29세 · 여성 · 활동 30~90분 · 희망 수면 8시간" / "선택 안 함 · 희망 수면 평균 7시간 33분" */
    fun summary(p: NextNightModel.ModelProfile): String {
        val parts = listOfNotNull(
            p.ageBand?.let { "${it}세" },
            p.sex?.let { s -> SEXES.firstOrNull { it.first == s }?.second },
            p.activityMinutes?.let { "활동 ${activityLabel(it)}" }
        )
        val desired = p.desiredSleepMinutes?.let { "희망 수면 ${hm(it)}" } ?: "희망 수면 평균 ${hm(NextNightModel.populationAverageMinutes(p))}"
        return (parts.ifEmpty { listOf("선택 안 함") } + desired).joinToString(" · ")
    }

    /** 420 → "7시간", 453 → "7시간 33분" */
    fun hm(min: Int): String = "${min / 60}시간" + if (min % 60 != 0) " ${min % 60}분" else ""

    fun activityLabel(min: Int): String = when {
        min < 30 -> ACTIVITY[0].second
        min < 90 -> ACTIVITY[1].second
        else -> ACTIVITY[2].second
    }
}
