package app.sleepwell.analysis

import app.sleepwell.health.AnalysisResult
import app.sleepwell.health.DirectInput
import app.sleepwell.health.LimitCode
import app.sleepwell.health.Recommendation
import app.sleepwell.user.DailyContext
import app.sleepwell.user.PortableFusionModel
import app.sleepwell.user.UserModelEngine
import app.sleepwell.user.UserProfile
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.roundToInt
import app.sleepwell.health.SleepRecord as WatchRecord
import app.sleepwell.user.SleepRecord as NightRecord

/*
 * 예상·권장 시각 = 서윤 새 모델(robust-next-night-research-v2) 연결 (소빈 · 2026-10-31, 통합 v6)
 *
 * 앱이 하는 일 두 가지 중
 *   1. 수면 분석(수면 압력·일주기 그래프) → 지금 그대로 (채윤 파이프라인, 1분 칸)
 *   2. 예상·권장 시각                    → 이 파일이 서윤 엔진(app.sleepwell.user, repo 파일 그대로)을 부른다
 *
 * 흐름: 파이프라인 결과(1분 칸 분석 + 세션 목록) → 밤 단위 한 줄씩 요약(= 일기) → 엔진 → Recommendation 칸만 바꿔 끼움
 * 그래서 화면(AnalysisDisplay·ScheduleCard)은 지금처럼 result.recommendation 을 읽으면 된다.
 *
 * 기준 시각: 고른 날짜(그날 아침 기상 기준, A안)의 **저녁 8시** — 엔진 규칙("20시에 그날 밤 예측").
 *   엔진은 8시까지 끝난 기록만 쓰므로 지난 날짜를 골라도 그 뒤 기록이 섞이지 않는다.
 *
 * 워치 기록 = 일기 (A안, 10/31 서윤 허락 "당근 괜찮지!!"): 엔진은 출처가 manual/diary 인 기록(사람이 쓴 일기)만 예측·개인화에 쓰고
 *   워치 기록(samsung_health)은 보조로만 쓴다. 우리 앱엔 일기 칸이 없어 → WATCH_AS_DIARY 로 워치 밤 기록을 일기로 넘긴다.
 *   false 로 바꾸면 워치 기록이 계산에서 빠져 모든 사람이 기본값으로 나온다.
 */
object NextNightModel {

    /** A안: 워치에서 뽑은 밤 기록을 일기(manual)로 넘긴다 (10/31 서윤 허락) */
    const val WATCH_AS_DIARY = true

    /** 같은 밤이 여러 조각으로 기록되면 사이 간격이 이 안일 때 한 밤으로 합친다 (서윤 Samsung 전처리 "2시간 이내 세션 병합") */
    const val MERGE_GAP_MIN = 120L

    /** 주 수면으로 볼 최소 길이 (A안 기상일 규칙과 같음: 3시간 이상) — 낮잠이 "밤"으로 들어가지 않게 */
    const val MAIN_SLEEP_MIN = 180L

    /**
     * 내 정보 (v7 11/05). 모두 고르지 않아도 된다 (null = 선택 안 함).
     *  - 나이대 18-29 / 30-44 / 45-59 / 60-80 · 성별 female / male · 하루 활동량(분)
     *  - 희망 수면시간(분): 서윤 새 엔진(11/01)의 목표 수면시간 출발점. 고르지 않으면 위 세 항목의 집단 평균(NHANES)으로 채운다
     *    → 고른 항목까지만 반영 (아무것도 안 고르면 전체 평균 453분 = 7시간 33분)
     */
    data class ModelProfile(
        val ageBand: String? = null,
        val sex: String? = null,
        val activityMinutes: Int? = null,
        val desiredSleepMinutes: Int? = null
    )

    /** 집단 평균 수면시간 표 (assets/models/population_prior.json, 서윤 NHANES 2017–2018) — install 때 읽는다 */
    private var priorGroups: List<Triple<Triple<String, String, String>, Int, Double>> = emptyList()
    private var priorGlobal: Double = 453.38

    /**
     * 희망 수면시간을 고르지 않았을 때 쓸 평균(분). 엔진의 집단 평균 찾기와 같은 순서:
     *  나이대·성별·활동량 → 나이대·성별 → 나이대 → 전체 (30명 이상인 집단만). 고르지 않은 항목은 "any".
     *  엔진처럼 성인 7~9시간 안으로 제한한다.
     */
    fun populationAverageMinutes(p: ModelProfile = profile): Int {
        val age = p.ageBand
        val sex = p.sex ?: "any"
        val act = p.activityMinutes?.let { if (it < 30) "low" else if (it < 90) "medium" else "high" } ?: "any"
        val keys = if (age == null) emptyList() else listOf(Triple(age, sex, act), Triple(age, sex, "any"), Triple(age, "any", "any")).distinct()
        val mean = keys.firstNotNullOfOrNull { k -> priorGroups.firstOrNull { it.first == k && it.second >= 30 }?.third } ?: priorGlobal
        return mean.roundToInt().coerceIn(420, 540)
    }

    /** 엔진에 넘길 희망 수면시간 = 고른 값, 없으면 집단 평균 */
    fun effectiveDesiredMinutes(p: ModelProfile = profile): Int = p.desiredSleepMinutes ?: populationAverageMinutes(p)

    private val SEOUL: ZoneId = ZoneId.of("Asia/Seoul")

    /**
     * 그동안 쌓인 설문 (지금 데이터의 참여자 것만: 실제 = "me", 합성 = "Test"). 화면이 계산 전에 넣어 준다.
     * 그날 설문의 피로도·개운함을 그날 아침에 끝난 잠(일기)에 붙인다 — 개운함 = 그날 아침 일어났을 때, 피로도 = 그 잠을 자고 보낸 하루의 피로.
     */
    @Volatile var surveyDays: List<SurveyDay> = emptyList()

    /**
     * 피로도 1~7(앱·혜지 설문, 1 = 매우 맑음 · 7 = 매우 피곤함) → 엔진 1~5 (10/31 소빈 결정).
     * 양 끝을 맞춰 늘인 값 1 + (x−1)×4/6 을 반올림 → 엔진 "잘 잔 밤" 기준(1~5에서 3 이하) = 1~7에서 4(보통) 이하.
     * 기준값 자체는 정답이 있는 값이 아니라 정한 규칙 (서윤 문서도 척도별 기준이 서로 보정되지 않았다고 명시) → 회의에서 공유
     */
    fun fatigueForEngine(x: Int?): Int? = when (x) { 1 -> 1; 2 -> 2; 3 -> 2; 4 -> 3; 5 -> 4; 6 -> 4; 7 -> 5; else -> null }
    private var engine: UserModelEngine? = null
    var profile: ModelProfile = ModelProfile()
    /** 마지막 계산에서 엔진이 실패한 이유 (디버그용) */
    var lastError: String? = null
        private set

    /** 앱 시작 때 한 번: assets/models/ 를 읽는 함수만 넘긴다 (MainActivity). 테스트에서는 파일 읽기로 넘긴다 */
    fun install(assetLoader: (String) -> ByteArray) {
        engine = UserModelEngine(assetLoader)
        try {
            val raw = JSONObject(assetLoader("models/population_prior.json").toString(Charsets.UTF_8).trimStart('\uFEFF'))
            val g = raw.getJSONArray("groups")
            priorGroups = (0 until g.length()).map { i ->
                val o = g.getJSONObject(i)
                Triple(Triple(o.getString("age_group"), o.getString("sex"), o.getString("activity_band")), o.getInt("n_people"), o.getDouble("mean_sleep_min"))
            }
            priorGlobal = raw.getJSONObject("global").getDouble("mean_sleep_min")
        } catch (e: Exception) { }
    }

    val isInstalled: Boolean get() = engine != null

    /**
     * (v8 11/06) 계산 기준 시각 = 기준 시각(그날 아침 기상)이 속한 날짜(한국 시간)의 저녁 8시.
     * 알람 해석(DirectInputParser.alarmAfter)도 이 함수를 같이 쓴다 — 두 곳의 "그날 밤" 기준이 어긋나지 않게.
     */
    fun cutoffOf(refMs: Long): ZonedDateTime = Instant.ofEpochMilli(refMs).atZone(SEOUL).toLocalDate().atTime(20, 0).atZone(SEOUL)

    /** 파이프라인 결과의 예상·권장(옛 HybridRecommendationEngine 값)을 새 엔진 값으로 바꾼다 */
    fun applyTo(result: AnalysisResult, direct: DirectInput?, features: Map<String, Double?>): AnalysisResult {
        val eng = engine ?: return result
        val refMs = result.inputPeriodEndMs.takeIf { it > 0 } ?: return result
        val cutoff = cutoffOf(refMs)
        return try {
            val nights = nightlyRecords(result.sleepRecords, direct)
            val up = userProfile(nights, cutoff).copy(dailyContext = dailyContext(cutoff, direct, features))
            val out = eng.compute(up, nights, cutoff.toInstant())
            lastError = null
            val p = out.outcomes.getJSONObject("research_predictions")
            val r = out.recommendation
            // (v7 11/05 소빈 결정) 알람을 넣으면 권장 기상 = 알람 (엔진은 알람과 평소 기상 중 이른 쪽).
            //  평소 기상(엔진이 알람 없이 고르는 기상)은 화면 안내("평소보다 ○분 늦은 기상이에요")에 쓰려고 함께 넘긴다.
            //  목표 수면시간은 엔진 값 그대로 → 권장 취침 = 알람 − 목표 수면시간 (저녁 8시 기준 시각보다 앞서면 8시)
            val alarm = direct?.targetWakeMs
            val habitualWake = if (alarm == null) ms(r.wakeTime)
                else eng.compute(up.copy(dailyContext = up.dailyContext?.copy(firstStart = null)), nights, cutoff.toInstant()).recommendation.wakeTime.let(::ms)
            // 목표 수면시간 = 엔진 개인화 값 (Recommendation.durationMinutes 는 "확보 가능한 수면 기회"라 저녁 8시에 잘리면 목표보다 짧다)
            val target = try { out.outcomes.getJSONObject("recommendation_feasibility").getInt("target_duration_min") } catch (e: Exception) { r.durationMinutes }
            val wakeMs = alarm ?: ms(r.wakeTime)
            val bedMs = if (alarm == null) ms(r.bedtime) else maxOf(alarm - target * 60_000L, cutoff.toInstant().toEpochMilli())
            val rec = Recommendation(
                recommendedBedTimeMs = bedMs,
                recommendedWakeTimeMs = wakeMs,
                recommendedSleepMin = target.toDouble(),     // 목표 수면시간. 실제 취침~기상이 이보다 짧으면 화면이 안내 (AnalysisPresenter.schedule)
                physicalBedTimeMs = avg(p, "physical", "bed"),
                physicalWakeTimeMs = avg(p, "physical", "wake"),
                predictedBedTimeMs = avg(p, "hybrid", "bed"),
                predictedWakeTimeMs = avg(p, "hybrid", "wake"),
                residualModelVersion = PortableFusionModel.MODEL_VERSION,
                modelStatus = "fusion_cmi_mesa",
                usedFallback = out.outcomes.optJSONObject("personalization")?.optString("mode") != "daily_recency_shrinkage",
                habitualWakeTimeMs = habitualWake
            )
            result.copy(
                recommendation = rec,
                modelVersion = "분석: Two-Process · 예측·권장: ${PortableFusionModel.MODEL_VERSION}",
                // 옛 엔진 기준 제한 코드는 새 엔진에 해당하지 않아 뺀다 (Ridge 학습 전 · 14일 단계 · 목표 기상 없으면 권장 없음).
                // 새 엔진 상황에 맞는 안내 문구는 화면 수정 때 (화면 수정 목록)
                predictionLimitations = result.predictionLimitations.filter {
                    it != LimitCode.RIDGE_UNTRAINED && it != LimitCode.FEW_RECORDS && it != LimitCode.NO_TARGET_WAKE
                }
            )
        } catch (e: Exception) {
            lastError = e.message ?: e::class.java.simpleName
            // 옛 엔진 값(새벽 5시 쏠림)을 보여 주지 않도록 비운다 → 화면은 "계산하지 못했어요"
            result.copy(recommendation = null)
        }
    }

    /**
     * 워치 세션 목록 → 밤 단위 한 줄(일기). 테스트용으로 공개.
     *  1. 간격 MERGE_GAP_MIN 안의 조각을 한 밤으로 합침
     *  2. 기상 날짜(한국 시간)마다 가장 긴 것 하나, MAIN_SLEEP_MIN 이상만 (낮잠 제외)
     *  3. 직접 입력한 수면(기록 보완)은 사람이 쓴 기록이라 항상 manual, 같은 기상일이면 워치 기록 대신 사용
     *  관측 시각(modifiedAt) = 기상 1분 뒤 → 엔진이 "그날 8시에 이미 알고 있던 기록"만 쓰게 된다
     */
    fun nightlyRecords(records: List<WatchRecord>, direct: DirectInput? = null, surveys: List<SurveyDay> = surveyDays): List<NightRecord> {
        val fatigueByDate = surveys.mapNotNull { sv -> fatigueForEngine(sv.fatigue)?.let { runCatching { LocalDate.parse(sv.date) }.getOrNull()?.to(it) } }.toMap()
        val restedByDate = surveys.mapNotNull { sv -> sv.rested?.takeIf { it in 1..5 }?.let { runCatching { LocalDate.parse(sv.date) }.getOrNull()?.to(it) } }.toMap()
        val merged = mutableListOf<LongArray>()
        records.sortedBy { it.startMs }.forEach { r ->
            val last = merged.lastOrNull()
            if (last != null && r.startMs - last[1] <= MERGE_GAP_MIN * 60_000L) last[1] = maxOf(last[1], r.endMs)
            else merged += longArrayOf(r.startMs, r.endMs)
        }
        val source = if (WATCH_AS_DIARY) "manual" else "samsung_health"
        val byWake = merged
            .filter { (it[1] - it[0]) >= MAIN_SLEEP_MIN * 60_000L }
            .groupBy { wakeDate(it[1]) }
            .mapValues { (_, v) -> v.maxBy { it[1] - it[0] } }
            .mapValues { (day, v) -> sd(v[1]).let { k -> night("watch:$day", v[0], v[1], source, fatigueByDate[k], restedByDate[k]) } }
            .toMutableMap()
        val ds = direct?.sleepStartMs
        val de = direct?.sleepEndMs
        if (ds != null && de != null && de > ds) byWake[wakeDate(de)] = night("input:${wakeDate(de)}", ds, de, "manual", fatigueByDate[sd(de)], restedByDate[sd(de)])
        return byWake.values.sortedBy { it.wakeTime }
    }

    private fun night(id: String, startMs: Long, endMs: Long, source: String, fatigue: Int? = null, rested: Int? = null) = NightRecord(
        id = id,
        day = Instant.ofEpochMilli(startMs).atZone(SEOUL).toLocalDate().toString(),
        bedtime = Instant.ofEpochMilli(startMs).toString(),
        wakeTime = Instant.ofEpochMilli(endMs).toString(),
        durationMinutes = ((endMs - startMs) / 60_000L).toInt(),
        rested = rested,   // 그날 설문의 아침 개운함 1~5. 개운함 4 이상 + 피로 3 이하(1~5) = "잘 잔 밤" → 5번 넘게 쌓이면 목표 수면시간 조정
        fatigue = fatigue,
        source = source,
        modifiedAt = Instant.ofEpochMilli(endMs + 60_000L).toString()
    )

    private fun wakeDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(SEOUL).toLocalDate()
    /** (v7) 그 잠에 붙일 설문 날짜 = 화면이 설문을 저장할 때와 같은 규칙 (SurveyCsv.surveyDateFor = 기상일, 한국 시간) */
    private fun sd(wakeMs: Long): LocalDate = LocalDate.parse(SurveyCsv.surveyDateFor(wakeMs))

    /**
     * 엔진 프로필. 평소 취침·기상은 기준 시각 전 최근 14밤의 중간값(없으면 23:30 / 07:30).
     * 가입일 = 첫 기록 하루 전 → 엔진이 가입일 이전 기록을 버리므로, 불러온 과거 기록도 모두 쓰이게.
     */
    fun userProfile(nights: List<NightRecord>, cutoff: ZonedDateTime): UserProfile {
        val before = nights.filter { Instant.parse(it.wakeTime).isBefore(cutoff.toInstant()) }.takeLast(14)
        fun clock(min: Int) = "%02d:%02d".format(((min % 1440) + 1440) % 1440 / 60, ((min % 1440) + 1440) % 1440 % 60)
        val bedAfter20 = before.map { val t = Instant.parse(it.bedtime).atZone(SEOUL); ((t.hour * 60 + t.minute) - 1200 + 1440) % 1440 }
        val wakeMin = before.map { val t = Instant.parse(it.wakeTime).atZone(SEOUL); t.hour * 60 + t.minute }
        val first = nights.minOfOrNull { Instant.parse(it.bedtime) } ?: cutoff.toInstant()
        return UserProfile(
            // 고르지 않은 항목: 엔진은 나이대를 모르면 전체 평균으로 기록만 한다 (11/01 엔진은 목표 수면 출발점 = 희망 수면시간)
            ageBand = profile.ageBand ?: "", sex = profile.sex ?: "any", activityMinutes = profile.activityMinutes ?: 0,
            usualBed = if (bedAfter20.isEmpty()) "23:30" else clock(median(bedAfter20) + 1200),
            usualWake = if (wakeMin.isEmpty()) "07:30" else clock(median(wakeMin)),
            desiredSleepMinutes = effectiveDesiredMinutes(profile),
            createdAt = first.minusSeconds(86_400).toString()
        )
    }

    /**
     * 설문 → 엔진 생활 맥락. 엔진은 "다음 날 첫 일정 − 준비 시간"을 기상 제약으로 쓴다 → 알람을 첫 일정, 준비 0분으로.
     * (엔진 규칙: 알람이 평소 기상보다 늦으면 평소 기상을 쓴다 → v7: applyTo 에서 알람을 그대로 쓰도록 바꿈.) 낮잠·카페인은 엔진도 기록만 한다.
     * 관측 시각은 8시 1분 전으로 둔다 — 지난 날짜 설문을 나중에 입력해도 그 밤 계산에 쓰이게 (앱 화면용 재계산이라 연구용 사전 예측 저장과는 별개)
     */
    private fun dailyContext(cutoff: ZonedDateTime, direct: DirectInput?, f: Map<String, Double?>): DailyContext? {
        val alarm = direct?.targetWakeMs
        val napEnd = f["napEndMs"]?.toLong()
        val napMin = f["napMinutes"]
        val caf = f["lastCaffeineMs"]?.toLong()
        val cafMg = f["caffeineMg"]
        if (alarm == null && napEnd == null && caf == null) return null
        return DailyContext(
            nightId = cutoff.toLocalDate().toString(),
            kind = "first",
            firstStart = alarm?.let { Instant.ofEpochMilli(it).toString() },
            preparationMinutes = 0,
            napStart = if (napEnd != null && napMin != null && napMin > 0) Instant.ofEpochMilli(napEnd - (napMin * 60_000).toLong()).toString() else null,
            napEnd = if (napEnd != null && napMin != null && napMin > 0) Instant.ofEpochMilli(napEnd).toString() else null,
            caffeineAt = caf?.let { Instant.ofEpochMilli(it).toString() },
            caffeineMg = if (caf != null) cafMg?.toInt() else null,
            observedAt = cutoff.minusMinutes(1).toInstant().toString()
        )
    }

    private fun ms(iso: String): Long = OffsetDateTime.parse(iso).toInstant().toEpochMilli()

    /** CMI·MESA 두 모델 평균 (엔진의 예상 취침 = 두 융합 모델 평균과 같은 방식) */
    private fun avg(p: JSONObject, arm: String, key: String): Long? = try {
        (ms(p.getJSONObject("${arm}_cmi").getString(key)) + ms(p.getJSONObject("${arm}_mesa").getString(key))) / 2
    } catch (e: Exception) { null }

    private fun median(v: List<Int>): Int { val s = v.sorted(); val n = s.size; return if (n % 2 == 1) s[n / 2] else (s[n / 2 - 1] + s[n / 2]) / 2 }
}
