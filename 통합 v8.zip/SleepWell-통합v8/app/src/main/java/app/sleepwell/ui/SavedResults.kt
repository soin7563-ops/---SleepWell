package app.sleepwell.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.sleepwell.analysis.ResultStore
import app.sleepwell.analysis.SavedResult
import app.sleepwell.analysis.SleepDataStore
import app.sleepwell.analysis.SurveyDay
import app.sleepwell.analysis.SurveyStore
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.sleepwell.analysis.SavedSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * 저장 기록 화면 (소빈 · 2026-10-24) — 작업 지시서 Ⅲ-4 "결과 저장 및 조회"
 *  - 「다음 수면 일정」에서 "이 결과 저장"을 누른 결과를, 그때 화면에 보인 글자 그대로 최신순으로 보여준다.
 *  - 저장 파일: 앱 전용 폴더 saved_results.csv (ResultStore). 폰 안에만 있고 서버로 보내지 않는다.
 *  - (v7 2026-11-05) 달력(저장한 날 점) → 날짜를 누르면 카드(머리글만) → 카드를 누르면 결과 화면 팝업(SavedSnapshot 으로 그때 화면 다시 그리기).
 *    설문 기록·보관 기록은 달력 아래 접어 둔다.
 */

/** 분석 화면과 저장 기록 화면이 같은 파일을 쓰도록 한 곳에서 정한다 */
fun savedResultsFile(context: android.content.Context) = File(context.filesDir, "saved_results.csv")

/** (2026-10-24) 실제 컨디션 입력에서 쌓인 설문 (웹 설문 CSV 내보내기와 같은 형식) */
fun surveyLogFile(context: android.content.Context) = File(context.filesDir, "survey_log.csv")

@Composable
fun SavedResultsScreen() {
    val context = LocalContext.current
    val file = remember { savedResultsFile(context) }
    var items by remember { mutableStateOf(ResultStore.load(file)) }
    val surveyFile = remember { surveyLogFile(context) }
    var surveys by remember { mutableStateOf(SurveyStore.load(surveyFile)) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    // 설문 기록 내보내기: 사용자가 고른 곳(다운로드 폴더 등)에 CSV 로 쓴다 → 서윤 언니 학습 코드에 그대로 넣을 수 있는 형식
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        exportMessage = try {
            context.contentResolver.openOutputStream(uri)?.use { it.write(SurveyStore.toCsv(surveys).toByteArray(Charsets.UTF_8)) }
            "내보냈어요 (${surveys.size}줄)."
        } catch (e: Exception) { "내보내지 못했어요: ${e.message}" }
    }
    // (v6) 보관한 수면 기록 지우기
    val sleepDir = remember { File(context.filesDir, "sleep_data") }
    var hasSleepData by remember { mutableStateOf(SleepDataStore.hasAny(sleepDir)) }
    var confirmClear by remember { mutableStateOf(false) }
    var clearMessage by remember { mutableStateOf<String?>(null) }

    // ── (v7 2026-11-05) 달력 — 11/1 회의 승인. 점 = 분석 화면에서 고른 날짜(그날 아침 기상일)에 저장한 결과가 있는 날 ──
    val today = remember { LocalDate.now(KST) }
    var month by remember { mutableStateOf(YearMonth.from(today)) }          // 처음엔 오늘이 속한 달
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    var openDay by remember { mutableStateOf<String?>(null) }
    var showData by remember { mutableStateOf(false) }
    // 가장 최근 날짜에서 저장한 결과의 "그 밤" 실제 기록 (보관 기록에서 한 번에 찾아 둠 — 헬스 커넥트로 다음 날 기록이 들어오면 채워짐)
    var actuals by remember { mutableStateOf<Map<String, SavedSnapshot.Actual>>(emptyMap()) }
    LaunchedEffect(items, hasSleepData) {
        actuals = withContext(Dispatchers.IO) {
            val merged = File(sleepDir, SleepDataStore.MERGED)
            if (!merged.isFile && SleepDataStore.hasAny(sleepDir)) try { SleepDataStore.buildMerged(sleepDir) } catch (e: Exception) { null }
            SavedSnapshot.actualIndex(merged)
        }
    }
    val counts = remember(items) { items.groupingBy { it.dayDate }.eachCount() }

    fun deleteItem(r: SavedResult) {
        items = ResultStore.delete(file, r.savedAtMs)
        try { SavedSnapshot.delete(context.filesDir, r.savedAtMs) } catch (e: Exception) { }
        if (items.none { it.dayDate == openDay }) openDay = null
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("저장 기록", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        CalendarCard(
            month = month, today = today, selected = selected, counts = counts,
            onPrev = { month = month.minusMonths(1) },
            onNext = { month = month.plusMonths(1) },
            onPickDate = {
                openSpinnerDatePicker(context, selected ?: month.atDay(1).let { if (YearMonth.from(today) == month) today else it }) { d ->
                    month = YearMonth.from(d); selected = d
                }
            },
            onSelect = { selected = it }
        )
        Spacer(Modifier.height(12.dp))
        val day = selected
        if (day == null) {
            Text("점이 있는 날짜를 누르면 저장한 결과가 보여요.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF777777))
        } else {
            val list = items.filter { it.dayDate == day.toString() }.sortedBy { it.savedAtMs }
            if (list.isEmpty()) {
                Text("${day.monthValue}/${day.dayOfMonth}(${dayOfWeekKo(day)})", style = MaterialTheme.typography.titleSmall)
                Text("이 날은 저장한 결과가 없어요.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF777777))
            } else {
                DayCard(day, list, onOpen = { openDay = day.toString() })
            }
        }

        // ── (v7) 데이터 관리 (접어 둠): 설문 기록 + 보관한 수면 기록 ──
        Spacer(Modifier.height(20.dp))
        val real = surveys.count { it.participant != "Test" }
        val dataLine = "설문 기록 ${real}일" + (surveys.size - real).takeIf { it > 0 }?.let { " (합성 ${it}일)" }.orEmpty() +
            " · 삼성 헬스 수면 기록 " + if (hasSleepData && actuals.isNotEmpty()) "${actuals.size}개 보관 중" else if (hasSleepData) "보관 중" else "없음"
        FoldRow("데이터 관리", showData, sub = dataLine) { showData = !showData }
        if (showData) {
            Text("설문 기록", style = MaterialTheme.typography.titleSmall)
            Text(
                // (v8 최종 11/06) 계산 반영 설명("피로도·개운함은 목표 수면시간에, 나머지는 학습 데이터로")은 뺐다 — 저장 위치 안내만
                "「실제 컨디션 입력」을 반영할 때마다 날짜별로 쌓여요. 이 폰 안에만 저장돼요.",
                style = MaterialTheme.typography.bodySmall, color = Color(0xFF777777)
            )
            if (surveys.isEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("아직 쌓인 설문이 없어요.", style = MaterialTheme.typography.bodyMedium)
            } else {
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    onClick = { exportMessage = null; exporter.launch("sleepwell_survey_log.csv") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("설문 기록 CSV 내보내기") }
                exportMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777)) }
                surveys.forEach { d ->
                    Spacer(Modifier.height(8.dp))
                    SurveyRow(d, onDelete = { surveys = SurveyStore.delete(surveyFile, d.participant, d.date) })
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("삼성 헬스 수면 기록", style = MaterialTheme.typography.titleSmall)
            Text(
                "불러온 삼성 헬스 기록(연동 + 불러오기)이 이 폰 안에 저장돼요. 삭제할 시 다음 분석부터 빠져요.",
                style = MaterialTheme.typography.bodySmall, color = Color(0xFF777777)
            )
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = { confirmClear = true }, enabled = hasSleepData, modifier = Modifier.fillMaxWidth()) {
                Text("보관한 수면 기록 지우기")
            }
            clearMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777)) }
        }
        if (confirmClear) {
            AlertDialog(
                onDismissRequest = { confirmClear = false },
                title = { Text("보관한 수면 기록을 지울까요?") },
                text = { Text("이 폰에 보관한 삼성 헬스 수면 기록이 지워져요. 되돌릴 수 없어요. (삼성 헬스 앱의 기록은 그대로예요)") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmClear = false
                        clearMessage = try { SleepDataStore.clear(sleepDir); hasSleepData = false; "지웠어요. 다음 분석부터 반영돼요." }
                            catch (e: Exception) { "지우지 못했어요: ${e.message}" }
                    }) { Text("지우기") }
                },
                dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("취소") } }
            )
        }
        Spacer(Modifier.height(40.dp))
    }

    openDay?.let { dd ->
        val list = items.filter { it.dayDate == dd }.sortedBy { it.savedAtMs }
        if (list.isNotEmpty()) SavedDayDialog(LocalDate.parse(dd), list, actuals, onClose = { openDay = null }, onDelete = { deleteItem(it) })
    }
}

private val KST: ZoneId = ZoneId.of("Asia/Seoul")
private fun dayOfWeekKo(d: LocalDate) = "월화수목금토일"[d.dayOfWeek.value - 1].toString()

/** 연·월·일을 드래그해서 고르는 창 (안드로이드 기본 날짜 고르기를 돌림판 모양으로) */
private fun openSpinnerDatePicker(context: android.content.Context, initial: LocalDate, onPick: (LocalDate) -> Unit) {
    val dlg = android.app.DatePickerDialog(
        context, android.R.style.Theme_Holo_Light_Dialog_NoActionBar,
        { _, y, m, d -> onPick(LocalDate.of(y, m + 1, d)) },
        initial.year, initial.monthValue - 1, initial.dayOfMonth
    )
    @Suppress("DEPRECATION")
    dlg.datePicker.calendarViewShown = false
    dlg.datePicker.spinnersShown = true
    dlg.show()
}

/** 달력: ◀ [2026년 11월] ▶ (제목을 누르면 연/월/일 돌림판) + 일~토 칸. 저장한 날에 점 하나, 오늘은 테두리, 고른 날은 채움 */
@Composable
private fun CalendarCard(
    month: YearMonth, today: LocalDate, selected: LocalDate?, counts: Map<String, Int>,
    onPrev: () -> Unit, onNext: () -> Unit, onPickDate: () -> Unit, onSelect: (LocalDate) -> Unit
) {
    val navy = Color(0xFF2F4A8A)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E5EA))
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPrev) { Text("◀", color = navy) }
                Text(
                    "${month.year}년 ${month.monthValue}월 ▾",
                    style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f).clickable(onClick = onPickDate).padding(vertical = 6.dp)
                )
                TextButton(onClick = onNext) { Text("▶", color = navy) }
            }
            Row(Modifier.fillMaxWidth()) {
                listOf("일", "월", "화", "수", "목", "금", "토").forEachIndexed { i, w ->
                    Text(w, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
                        color = when (i) { 0 -> Color(0xFFC0392B); 6 -> Color(0xFF2F5FB3); else -> Color(0xFF888888) })
                }
            }
            val lead = month.atDay(1).dayOfWeek.value % 7          // 일요일 = 0
            val cells = List(lead) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth()) {
                    (0 until 7).forEach { i ->
                        val d = week.getOrNull(i)
                        Box(Modifier.weight(1f).height(46.dp), contentAlignment = Alignment.TopCenter) {
                            if (d != null) {
                                val n = counts[d.toString()] ?: 0
                                val isSel = d == selected
                                Column(
                                    Modifier.clickable { onSelect(d) }.padding(top = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        Modifier.size(30.dp)
                                            .background(if (isSel) navy else Color.Transparent, CircleShape)
                                            .border(if (d == today && !isSel) 1.5.dp else 0.dp, if (d == today && !isSel) navy else Color.Transparent, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${d.dayOfMonth}", style = MaterialTheme.typography.bodyMedium,
                                            color = when { isSel -> Color.White; i == 0 -> Color(0xFFC0392B); i == 6 -> Color(0xFF2F5FB3); else -> Color(0xFF1F2933) })
                                    }
                                    Row(Modifier.height(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        if (n > 0) Box(Modifier.size(5.dp).background(Color(0xFF2F7A55), CircleShape))   // (v7) 저장 수와 관계없이 점 하나
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * (v7 11/05) 날짜를 고르면 보이는 카드 하나 — 저장마다 두 줄(내 정보 · 그날 입력 / 권장 또는 실제), 저장 사이는 얇은 선. 누르면 팝업
 */
@Composable
private fun DayCard(day: LocalDate, list: List<SavedResult>, onOpen: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E5EA))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${day.monthValue}/${day.dayOfMonth}(${dayOfWeekKo(day)}) 기상 · 저장 ${list.size}개",
                    style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text("›", style = MaterialTheme.typography.titleMedium, color = Color(0xFF999999))
            }
            list.forEachIndexed { i, r ->
                if (i > 0) Box(Modifier.padding(top = 8.dp).fillMaxWidth().height(1.dp).background(Color(0xFFE6E8EC)))
                Spacer(Modifier.height(6.dp))
                Text("${num(i)} " + inputLine(r), style = MaterialTheme.typography.labelMedium, color = Color(0xFF4A5363))
                Text(resultLine(r), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold,
                    color = if (r.isPast) ACTUAL else REC)
            }
        }
    }
}

private val REC = Color(0xFF1E6B3D)
private val ACTUAL = Color(0xFF2F4A6D)
private fun num(i: Int) = "①②③④⑤⑥⑦⑧⑨".getOrElse(i) { '·' }.toString()

/** 내 정보 · 그날 입력 한 줄 */
private fun inputLine(r: SavedResult): String =
    listOf(r.profileText.ifBlank { "내 정보 없음" }, r.surveyText.ifBlank { "그날 입력 없음" }).joinToString(" · ")

/** 권장 글자 정리: 예전 형식 "07:00 기상 목표 → 23:43 전에 취침 · 권장 수면 7시간 16분" 도 "23:43 취침 → 07:00 기상 · 권장 수면 7시간 16분" 으로 */
private fun normRec(t: String): String =
    Regex("""^(\d{1,2}:\d{2}) 기상 목표 → (\d{1,2}:\d{2}) 전에 취침""").replace(t) { m -> "${m.groupValues[2]} 취침 → ${m.groupValues[1]} 기상" }

/** 권장 → (취침, 기상, 수면시간). 형식이 다르면 null. (v8) 수면시간이 음수인 옛 저장분도 null */
private fun recParts(t: String): Triple<String, String, String?>? =
    if (brokenRec(t)) null
    else Regex("""^(\d{1,2}:\d{2}) 취침 → (\d{1,2}:\d{2}) 기상(?: · 권장 수면 (.+))?$""").find(normRec(t).trim())?.let {
        Triple(it.groupValues[1], it.groupValues[2], it.groupValues[3].ifBlank { null })
    }

/** (v8 11/06) v7 이하에서 늦은 알람(예: 기상 07:08 + 알람 11:00)을 같은 날로 처리해 "−540분" 같은 음수 수면으로 저장된 권장 */
private fun brokenRec(t: String): Boolean = Regex("""(^|[^\d])-\d+분""").containsMatchIn(t)
private const val BROKEN_REC_TEXT = "이전 버전에서 알람 시각을 잘못 처리해 저장된 값이에요 (수면시간이 음수). 다시 저장해 주세요."

/** 권장 글자를 화면에 보여 줄 때: 음수 수면 저장분은 안내 문장으로 */
private fun recShown(t: String): String = if (brokenRec(t)) BROKEN_REC_TEXT else t.ifBlank { "—" }

/** "10/25 04:52 취침 → 10/25 07:00 기상 · 차이 문장" → (취침, 기상, 뒷부분) */
private fun pairParts(t: String): Triple<String, String, String?>? =
    Regex("""^(.+?) 취침 → (.+?) 기상(?: · (.+))?$""").find(t.trim())?.let {
        Triple(it.groupValues[1], it.groupValues[2], it.groupValues[3].ifBlank { null })
    }

/** 결과 한 줄: 지난 날 = 실제 / 가장 최근 날 = 권장 ("권장 23:43 취침 → 07:00 기상 · 7시간 16분") */
private fun resultLine(r: SavedResult): String =
    if (r.isPast) "실제 " + (pairParts(r.actualText)?.let { "${it.first} 취침 → ${it.second} 기상" } ?: r.actualText.ifBlank { "—" })
    else "권장 " + (recParts(r.recText)?.let { "${it.first} 취침 → ${it.second} 기상" + (it.third?.let { d -> " · $d" } ?: "") } ?: recShown(r.recText))

/**
 * (v7 11/05) 그날 저장한 결과를 한 화면에 (화면을 꽉 채우는 팝업, ← 또는 뒤로가기로 닫힘)
 *  1. 지난밤 수면 분석 (개념 · 그래프 · 해설) — 물리 모델이 수면 기록만으로 계산해서 같은 날이면 같다 → 한 번만 (가장 최근 저장의 계산 재료로 다시 그림)
 *  2. 「저장한 일정」: 저장마다 [내 정보·그날 입력] → [예상 카드] → [권장 카드(지난 날짜는 실제 카드)] → 평소 패턴
 *  저장할 때 남긴 글자로 그린다 (다시 계산하지 않음) → 예전 저장분도 같은 모양
 */
@Composable
private fun SavedDayDialog(
    day: LocalDate, list: List<SavedResult>, actuals: Map<String, SavedSnapshot.Actual>,
    onClose: () -> Unit, onDelete: (SavedResult) -> Unit
) {
    val context = LocalContext.current
    var baseReplay by remember(day) { mutableStateOf<SavedSnapshot.Replay?>(null) }
    var hasBase by remember(day) { mutableStateOf(true) }
    var loading by remember(day) { mutableStateOf(true) }
    LaunchedEffect(day, list.map { it.savedAtMs }) {
        val pick = withContext(Dispatchers.IO) {
            list.sortedByDescending { it.savedAtMs }.firstNotNullOfOrNull { r -> SavedSnapshot.load(context.filesDir, r.savedAtMs) }
        }
        hasBase = pick != null
        baseReplay = pick?.let { withContext(Dispatchers.Default) { SavedSnapshot.replay(it) } }
        loading = false
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.White) {
            Column(Modifier.fillMaxSize()) {
                TextButton(onClick = onClose, modifier = Modifier.padding(start = 4.dp, top = 4.dp)) { Text("← 저장 기록") }
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp)
                ) {
                    // 제목: 크고 얇던 글씨 → 조금 작고 굵게 (아래 글씨와 균형)
                    Text("${day.monthValue}/${day.dayOfMonth}(${dayOfWeekKo(day)}) 기상 · 저장 ${list.size}개",
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp, fontWeight = FontWeight.SemiBold))
                    Spacer(Modifier.height(4.dp))
                    Text("데이터: ${list.last().source}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777))
                    Spacer(Modifier.height(10.dp))
                    // 1. 지난밤 수면 분석 (한 번만)
                    val shown = baseReplay?.display
                    when {
                        loading -> Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp))
                            Text("  저장할 때의 기록으로 다시 그리는 중…", style = MaterialTheme.typography.bodyMedium)
                        }
                        !hasBase -> Text("이 날 기록은 결과 화면 저장 기능 전에 저장돼서, 수면 분석 그래프 없이 저장한 일정만 볼 수 있어요.",
                            style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A5A00))
                        shown == null -> baseReplay?.error?.let { n ->
                            Text(n.title, style = MaterialTheme.typography.titleSmall)
                            n.lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                        else -> AnalysisContent(shown, list.last().source, UiZone.current, onAskTargetWake = {}, onSave = null, showSchedule = false, showSource = false)
                    }
                    // 2. 저장한 일정
                    // (v7 11/05 B안) 바깥 카드 없이 제목만 → 저장마다 외곽선 카드 하나 (저장이 많아도 서로 나뉘어 보이게)
                    Spacer(Modifier.height(20.dp))
                    Text("저장한 일정", style = MaterialTheme.typography.titleMedium)
                    Text("내 정보·그날 입력에 따라 권장이 달라져요. 저장 ${list.size}개",
                        style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777))
                    list.forEachIndexed { i, r ->
                        Spacer(Modifier.height(12.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFD5DAE2))
                        ) {
                            Column(Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp, top = 4.dp)) {
                                SavedEntry(i, r, actual = if (r.isPast) null else actuals[r.dayDate], onDelete = { onDelete(r) })
                            }
                        }
                    }
                    Spacer(Modifier.height(30.dp))
                }
            }
        }
    }
}

private val PRED_BG = Color(0xFFF6F7F9)
private val PRED_LINE = Color(0xFFD9DDE3)
private val PRED_TEXT = Color(0xFF4A5363)
private val REC_BG = Color(0xFFF0F8F2)
private val REC_LINE = Color(0xFFBFDCC8)

/** 예상 / 실제 상자: 이름 + 취침 → 기상 (수면 분석 화면의 일정 카드와 같은 모양) */
@Composable
private fun TimesBox(title: String, sub: String, pairText: String, bg: Color, line: Color, fg: Color, extra: String? = null) {
    val p = pairParts(pairText)
    Card(colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, line), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(title, style = MaterialTheme.typography.labelLarge, color = fg, fontWeight = FontWeight.Bold)
                if (sub.isNotBlank()) Text("  · $sub", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777))
            }
            if (p == null) Text(pairText.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall)
            else Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text("취침", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777))
                    Text(p.first, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Text("→", fontSize = 16.sp, color = Color(0xFF777777), modifier = Modifier.padding(horizontal = 6.dp))
                Column(Modifier.weight(1f)) {
                    Text("기상", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777))
                    Text(p.second, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            (extra ?: p?.third)?.let { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)) }
        }
    }
}

/** 「저장한 일정」 한 묶음: 머리글(저장 시각 · 삭제) → 회색 상자(내 정보·그날 입력) → 권장 카드(지난 날은 실제 카드) → 작은 글씨 */
@Composable
private fun SavedEntry(i: Int, r: SavedResult, actual: SavedSnapshot.Actual?, onDelete: () -> Unit) {
    val savedText = SimpleDateFormat("M/d(E) HH:mm", Locale.KOREA).apply { timeZone = UiZone.current.tz }.format(Date(r.savedAtMs))
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("${num(i)} $savedText 저장", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        TextButton(onClick = onDelete) { Text("삭제") }
    }
    // 내 정보·그날 입력 = 칠 없이 왼쪽 세로선 (지난밤 수면 분석 두 줄과 같은 모양 → 아래 회색 예상 카드와 겹쳐 보이지 않게)
    Column(
        Modifier
            .fillMaxWidth()
            .drawBehind { drawLine(Color(0xFFA9BCDB), Offset(1.5f.dp.toPx(), 0f), Offset(1.5f.dp.toPx(), size.height), 3.dp.toPx()) }
            .padding(start = 12.dp, top = 1.dp, bottom = 1.dp)
    ) {
        Line("내 정보", r.profileText.ifBlank { "없음" }, ACTUAL)
        Line("그날 입력", r.surveyText.ifBlank { "없음" }, ACTUAL)
    }
    // (v7 11/05) 수면 분석 화면처럼 예상 카드 + 권장(지난 날은 실제) 카드를 저장마다 모두
    Spacer(Modifier.height(8.dp))
    TimesBox("예상", "", r.modelText, PRED_BG, PRED_LINE, PRED_TEXT)
    Spacer(Modifier.height(8.dp))
    if (r.isPast) {
        TimesBox("실제", "", r.actualText, Color.White, PRED_LINE, ACTUAL)
    } else {
        val rp = recParts(r.recText)
        Card(colors = CardDefaults.cardColors(containerColor = REC_BG), shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, REC_LINE), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("권장", style = MaterialTheme.typography.labelLarge, color = REC, fontWeight = FontWeight.Bold)
                if (rp == null) Text(recShown(r.recText), style = MaterialTheme.typography.bodySmall)
                else {
                    Spacer(Modifier.height(2.dp))
                    Text("${rp.second}에 일어나려면" + (rp.third?.let { " ($it 수면)" } ?: ""), style = MaterialTheme.typography.bodySmall, color = REC)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(rp.first, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = REC)
                        Text("  전에 취침", style = MaterialTheme.typography.bodyMedium, color = REC)
                    }
                }
            }
        }
        // 그 밤에 실제로 잔 시각 (다음 날 기록이 들어온 경우)
        if (actual != null && rp != null) {
            val fmt = SimpleDateFormat("HH:mm", Locale.KOREA).apply { timeZone = UiZone.current.tz }
            val cmp = recMs(r.dayDate, rp.first, rp.second)?.let { (b, w) -> SavedSnapshot.compareText("권장과 비교", b, w, actual) }
            Text("그 밤 실제 ${fmt.format(Date(actual.bedMs))} 취침 → ${fmt.format(Date(actual.wakeMs))} 기상" + (cmp?.let { " · $it" } ?: ""),
                style = MaterialTheme.typography.labelSmall, color = ACTUAL, modifier = Modifier.padding(top = 6.dp))
        }
    }
    if (r.habitText.isNotBlank() && r.habitText != "—")
        Text("참고 · 평소 패턴 ${r.habitText} (최근 7일 중간값)", style = MaterialTheme.typography.labelSmall, color = PRED_TEXT, modifier = Modifier.padding(top = 6.dp))
}

/** 권장 "23:43"·"07:00" → 그 밤 시각(ms). 낮 12시 넘은 취침은 그날 밤, 그 전은 다음 날 새벽. 기상은 다음 날 */
private fun recMs(dayDate: String, bed: String, wake: String): Pair<Long, Long>? = try {
    val d = LocalDate.parse(dayDate)
    fun at(day: LocalDate, hm: String): Long { val (h, m) = hm.split(":").map { it.toInt() }; return day.atTime(h, m).atZone(KST).toInstant().toEpochMilli() }
    val bh = bed.substringBefore(":").toInt()
    at(if (bh >= 12) d else d.plusDays(1), bed) to at(d.plusDays(1), wake)
} catch (e: Exception) { null }

@Composable
private fun FoldRow(title: String, open: Boolean, sub: String? = null, onToggle: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E5EA))
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium)
                sub?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777)) }
            }
            Text(if (open) "▾" else "›", color = Color(0xFF999999))
        }
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun Line(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = color, modifier = Modifier.weight(0.28f))
        Text(value, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(0.72f))
    }
}

@Composable
private fun SurveyRow(d: SurveyDay, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E5EA))
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.date.substring(5).replace('-', '/') + if (d.participant == "Test") "  (합성)" else "",
                    style = MaterialTheme.typography.labelLarge)
                Text(d.summary(), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDelete) { Text("삭제") }
        }
    }
}
