package app.sleepwell.analysis

import app.sleepwell.health.AnalysisResult
import app.sleepwell.health.CsvFileSource
import app.sleepwell.health.DirectInput
import app.sleepwell.health.HealthResult
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Properties
import app.sleepwell.health.SleepRecord as WatchRecord

/*
 * 저장한 결과를 "그때 화면 그대로" 다시 보기 (소빈 · 2026-11-05, 통합 v7) — 11/1 회의 "저장 기록 달력" 승인, 방식 ①
 *
 * "이 결과 저장"을 누를 때 결과 글자(ResultStore)와 함께 **계산 재료**를 여기에 남긴다.
 *   saved_snapshots/inputs/<내용 해시>.csv    그때 분석한 수면 기록 사본 (합성 데이터도 그대로)
 *     (v7 11/05) 같은 기록이면 한 벌만 두고 여러 저장이 함께 쓴다 → 같은 데이터로 여러 번 저장해도 용량이 늘지 않음.
 *     마지막으로 쓰던 저장을 지우면 그 사본도 지운다. (예전 저장분은 <저장 시각>/input.csv 그대로 읽음)
 *   saved_snapshots/<저장 시각>/meta.properties 직접 입력(기록 보완·목표 기상) · 피로도 · 고른 날 · 내 정보 · 참여자
 *                             /survey.csv      그때 「실제 컨디션 입력」에 반영한 설문 (없으면 없음)
 *                             /surveys.csv     그때까지 쌓인 설문 (피로도·개운함을 일기에 붙이는 데 씀)
 * 저장 기록에서 카드를 누르면 replay() 가 화면(AnalysisScreen)과 **같은 순서**로 다시 계산한다
 *   → 그래프 · 설명 ①②③ · 수면 일정 카드가 그때와 같게 나온다 (모델이 바뀌면 숫자는 달라질 수 있음 → 저장 당시 값 같이 표시)
 * 가장 최근 날짜에서 저장한 결과는, 그 밤의 실제 기록이 나중에 들어오면(헬스 커넥트·새 내보내기) actualAfter() 로 찾아 보여 준다.
 * 폰 안에만 저장. 기록을 지우면 같이 지운다. Android 없이 시험할 수 있게 File 만 받는다.
 */
object SavedSnapshot {

    const val DIR = "saved_snapshots"
    private val SEOUL: ZoneId = ZoneId.of("Asia/Seoul")

    data class Snapshot(
        val input: File,
        val direct: DirectInput?,
        val condition: Int?,
        val survey: SurveyDay?,
        val surveys: List<SurveyDay>,
        val profile: NextNightModel.ModelProfile,
        /** 고른 날 (null = 가장 최근 날짜) */
        val dayStartMs: Long?,
        val dayBasisMs: Long?,
        val participant: String
    )

    data class Replay(val display: AnalysisDisplay?, val result: AnalysisResult?, val error: Notice?)

    fun dir(base: File, savedAtMs: Long) = File(base, "$DIR/$savedAtMs")
    fun exists(base: File, savedAtMs: Long) = File(dir(base, savedAtMs), "meta.properties").isFile
    private fun inputsDir(base: File) = File(base, "$DIR/inputs")

    /** 이 저장이 쓰는 기록 사본의 해시 (예전 저장분은 null) */
    private fun inputHash(base: File, savedAtMs: Long): String? = try {
        val m = File(dir(base, savedAtMs), "meta.properties")
        if (!m.isFile) null else Properties().apply { m.inputStream().use { load(it) } }.getProperty("inputSha")
    } catch (e: Exception) { null }

    /** 저장을 지운다. 그 기록 사본을 쓰는 다른 저장이 없으면 사본도 지운다 */
    fun delete(base: File, savedAtMs: Long) {
        val sha = inputHash(base, savedAtMs)
        dir(base, savedAtMs).deleteRecursively()
        if (sha != null) {
            val stillUsed = File(base, DIR).listFiles()?.any { f -> f.isDirectory && f.name != "inputs" && f.name.toLongOrNull()?.let { inputHash(base, it) } == sha } == true
            if (!stillUsed) File(inputsDir(base), "$sha.csv").delete()
        }
    }

    private fun sha256(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins -> val buf = ByteArray(64 * 1024); while (true) { val n = ins.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun save(
        base: File, savedAtMs: Long, input: File, direct: DirectInput?, condition: Int?, survey: SurveyDay?,
        surveys: List<SurveyDay>, profile: NextNightModel.ModelProfile, dayStartMs: Long?, dayBasisMs: Long?, participant: String
    ) {
        val d = dir(base, savedAtMs).apply { deleteRecursively(); mkdirs() }
        // 기록 사본: 내용이 같으면 이미 있는 것을 같이 쓴다
        val sha = sha256(input)
        val shared = File(inputsDir(base).apply { mkdirs() }, "$sha.csv")
        if (!shared.isFile) {
            val tmp = File(shared.parentFile, "$sha.tmp")
            input.copyTo(tmp, overwrite = true)
            if (!tmp.renameTo(shared)) { tmp.copyTo(shared, overwrite = true); tmp.delete() }
        }
        val p = Properties()
        fun put(k: String, v: Any?) { if (v != null) p.setProperty(k, v.toString()) }
        put("inputSha", sha)
        put("sleepStartMs", direct?.sleepStartMs); put("sleepEndMs", direct?.sleepEndMs)
        put("targetWakeMs", direct?.targetWakeMs); put("plannedBedMs", direct?.plannedBedMs)
        put("condition", condition)
        put("dayStartMs", dayStartMs); put("dayBasisMs", dayBasisMs)
        put("ageBand", profile.ageBand); put("sex", profile.sex); put("activityMinutes", profile.activityMinutes)
        put("desiredSleepMinutes", profile.desiredSleepMinutes)
        put("participant", participant)
        File(d, "meta.properties").outputStream().use { p.store(it, "SleepWell saved result snapshot") }
        if (survey != null) File(d, "survey.csv").writeText(SurveyStore.toCsv(listOf(survey)), Charsets.UTF_8)
        File(d, "surveys.csv").writeText(SurveyStore.toCsv(surveys), Charsets.UTF_8)
    }

    fun load(base: File, savedAtMs: Long): Snapshot? {
        val d = dir(base, savedAtMs)
        val metaFile = File(d, "meta.properties")
        if (!metaFile.isFile) return null
        return try {
            val p = Properties().apply { metaFile.inputStream().use { load(it) } }
            val input = p.getProperty("inputSha")?.let { File(inputsDir(base), "$it.csv") } ?: File(d, "input.csv")
            if (!input.isFile) return null
            fun l(k: String) = p.getProperty(k)?.toLongOrNull()
            val direct = DirectInput(l("sleepStartMs"), l("sleepEndMs"), l("targetWakeMs"), l("plannedBedMs"))
                .takeIf { it.sleepStartMs != null || it.sleepEndMs != null || it.targetWakeMs != null || it.plannedBedMs != null }
            fun surveysOf(name: String) = File(d, name).takeIf { it.isFile }?.let { SurveyCsv.parse(it.readText(Charsets.UTF_8)).days } ?: emptyList()
            Snapshot(
                input = input, direct = direct, condition = p.getProperty("condition")?.toIntOrNull(),
                survey = surveysOf("survey.csv").firstOrNull(), surveys = surveysOf("surveys.csv"),
                // (v7) 내 정보는 고르지 않은 항목이 없을 수 있다 (없음 = 선택 안 함, 희망 수면시간 없음 = 집단 평균)
                profile = NextNightModel.ModelProfile(
                    ageBand = p.getProperty("ageBand"), sex = p.getProperty("sex")?.takeIf { it != "any" },
                    activityMinutes = p.getProperty("activityMinutes")?.toIntOrNull(),
                    desiredSleepMinutes = p.getProperty("desiredSleepMinutes")?.toIntOrNull()
                ),
                dayStartMs = l("dayStartMs"), dayBasisMs = l("dayBasisMs"),
                participant = p.getProperty("participant") ?: "me"
            )
        } catch (e: Exception) { null }
    }

    /**
     * 화면(AnalysisScreen)과 같은 순서로 다시 계산한다.
     *  1. 그때 파일 + 그때 직접 입력·설문으로 전체 계산 (화면의 runAnalysis)
     *  2. 가장 최근 날짜에서 저장했으면 그대로 정리 / 지난 날짜면 그날 설문 알람으로 그날 기준 다시 계산 (화면의 지난 날 계산)
     * 새 모델이 쓰는 내 정보·쌓인 설문은 계산하는 동안만 그때 값으로 바꿨다가 되돌린다.
     */
    fun replay(s: Snapshot): Replay = synchronized(NextNightModel) {
        val oldProfile = NextNightModel.profile
        val oldSurveys = NextNightModel.surveyDays
        try {
            NextNightModel.profile = s.profile
            NextNightModel.surveyDays = s.surveys
            val baseRes = AnalysisRunner.runFile(s.input, s.direct, s.survey?.featureValues(SurveyCsv.SURVEY_ZONE) ?: emptyMap())
            if (baseRes !is HealthResult.Success) return Replay(null, null, AnalysisPresenter.failureNotice(baseRes))
            val base = baseRes.data
            val latestRef = base.scHistory.lastOrNull()?.timestampMs ?: base.calculationTimeMs
            val dataStart = listOfNotNull(base.sleepRecords.minOfOrNull { it.startMs }, base.scHistory.firstOrNull()?.timestampMs).minOrNull()
            if (s.dayStartMs == null && s.dayBasisMs == null) {
                return Replay(AnalysisPresenter.build(base, null, direct = s.direct, condition = s.condition,
                    latestRefMs = latestRef, dataStartMs = dataStart, survey = s.survey), base, null)
            }
            val days = AnalysisPresenter.days(base.sleepRecords, s.direct, latestRef, dataStart)
            // 기준 시각(그날 기상)으로 먼저 찾는다 — 표시 시간대(한국/UTC)를 바꿔도 같은 날을 찾게
            val sel = days.firstOrNull { s.dayBasisMs != null && it.basisMs == s.dayBasisMs }
                ?: days.firstOrNull { it.startMs == s.dayStartMs }
                ?: return Replay(null, null, Notice("이 날을 다시 계산할 수 없어요", listOf("저장할 때의 기록에서 이 날짜를 찾지 못했어요.")))
            if (sel.isLatest) {
                return Replay(AnalysisPresenter.build(base, null, direct = s.direct, condition = s.condition,
                    latestRefMs = latestRef, dataStartMs = dataStart, survey = s.survey), base, null)
            }
            val daySurvey = s.surveys.firstOrNull { it.date == SurveyCsv.surveyDateFor(sel.basisMs) }
            val target = DirectInputParser.alarmAfter(sel.basisMs, daySurvey?.alarmTime)   // (v8) 화면의 지난 날 계산과 같은 규칙
            val pastDirect = DirectInput(s.direct?.sleepStartMs, s.direct?.sleepEndMs, target, null)
                .takeIf { it.sleepStartMs != null || it.targetWakeMs != null }
            val sleepTarget = AnalysisRunner.sleepTargetUntil(base.sleepRecords, sel.basisMs)
            val res = AnalysisRunner.runFileAt(s.input, pastDirect, sel.basisMs, sleepTarget,
                daySurvey?.featureValues(SurveyCsv.SURVEY_ZONE) ?: emptyMap())
            if (res !is HealthResult.Success) return Replay(null, null, AnalysisPresenter.failureNotice(res, pastDay = true))
            Replay(AnalysisPresenter.build(res.data, sel.startMs, direct = pastDirect, latestRefMs = latestRef, dataStartMs = dataStart), res.data, null)
        } catch (e: Exception) {
            Replay(null, null, Notice("다시 계산하지 못했어요", listOf(e.message ?: e::class.java.simpleName)))
        } finally {
            NextNightModel.profile = oldProfile
            NextNightModel.surveyDays = oldSurveys
        }
    }

    data class Actual(val bedMs: Long, val wakeMs: Long)

    /**
     * 가장 최근 날짜에서 저장한 결과의 "그 밤" 실제 기록 — 지금 보관 중인 수면 기록(내보내기 + 헬스 커넥트)에서 찾는다.
     * 그 밤 = 고른 날(dayDate) 다음 날 아침에 끝난 주 수면 (새 모델 밤 요약과 같은 규칙: 2시간 안 조각 합침 · 3시간 이상 · 가장 긴 것)
     * 합성 데이터나 아직 기록이 안 들어왔으면 null
     */
    fun actualAfter(storeFile: File?, dayDate: String): Actual? = actualIndex(storeFile)[dayDate]

    /** 보관 기록 전체를 한 번 읽어 "고른 날(yyyy-MM-dd) → 그 밤의 실제 기록" 표로 (저장 기록 카드마다 다시 읽지 않게) */
    fun actualIndex(storeFile: File?): Map<String, Actual> {
        if (storeFile == null || !storeFile.isFile) return emptyMap()
        return try {
            val src = CsvFileSource()
            val sessions = src.groupIntoSessionsForPipeline(storeFile.inputStream().use { src.parseSleepStageCsvForPipeline(it) })
            val records = sessions.map { WatchRecord(it.sessionId, it.startMs, it.endMs, (it.endMs - it.startMs) / 60_000.0, emptyMap()) }
            NextNightModel.nightlyRecords(records, surveys = emptyList()).associate { n ->
                val wakeDay: LocalDate = Instant.parse(n.wakeTime).atZone(SEOUL).toLocalDate()
                wakeDay.minusDays(1).toString() to Actual(Instant.parse(n.bedtime).toEpochMilli(), Instant.parse(n.wakeTime).toEpochMilli())
            }
        } catch (e: Exception) { emptyMap() }
    }

    /** "예상보다 26분 늦게 잠들고, 12분 일찍 일어났어요" 같은 한 줄 (10분 이내는 비슷하게) */
    fun compareText(label: String, bedMs: Long?, wakeMs: Long?, actual: Actual): String? {
        if (bedMs == null && wakeMs == null) return null
        fun part(a: Long, p: Long, late: String, early: String, same: String): String {
            val m = ((a - p) / 60_000L).toInt()
            val abs = kotlin.math.abs(m)
            val t = if (abs >= 60) "${abs / 60}시간" + (if (abs % 60 > 0) " ${abs % 60}분" else "") else "${abs}분"
            return when { abs <= 10 -> same; m > 0 -> "$t $late"; else -> "$t $early" }
        }
        val bed = bedMs?.let { part(actual.bedMs, it, "늦게 잠들고", "일찍 잠들고", "비슷하게 잠들고") }
        val wake = wakeMs?.let { part(actual.wakeMs, it, "늦게 일어났어요", "일찍 일어났어요", "비슷하게 일어났어요") }
        return "$label · " + listOfNotNull(bed, wake).joinToString(", ")
    }
}
