package app.sleepwell.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.sleepwell.analysis.Schedule
import app.sleepwell.analysis.ScheduleLevel
import app.sleepwell.analysis.ScheduleTimes

/*
 * 「다음 수면 일정」 카드 (소빈 · 2026-10-24) — 작업 지시서 Ⅲ-3
 *  (제목: '오늘 밤' → '다음 수면'. 기준은 폰 날짜가 아니라 기준 시각(마지막 기록)이라, 과거 파일에서 '오늘'이 헷갈리지 않게)
 *
 * 구성 (2026-10-24 A안): 제목(○/○ 밤 수면 일정)·기준(그날 기상) → 상태 줄(v8 최종: 안내가 있을 때만) → [예상] 시각만 → [권장]
 *   → 참고(작게): 지난 날은 실제로 잔 시각, 내 평소 패턴(최근 7일 중간값) → ⓘ 연구용 안내
 *  - 예상(회색)과 권장(초록)은 색과 얇은 테두리로만 구분한다 (진한 세로 줄 없음, 2026-10-24 소빈 요청).
 *  - 값·문장은 전부 AnalysisPresenter.schedule() 이 만든다. 이 파일은 그리기만 한다.
 */

private val LINE = Color(0xFFE2E5EA)
private val PRED_BG = Color(0xFFF6F7F9)
private val PRED_LINE = Color(0xFFD9DDE3)
private val PRED_TEXT = Color(0xFF4A5363)
private val REC_BG = Color(0xFFF0F8F2)
private val REC_LINE = Color(0xFFBFDCC8)
private val REC_TEXT = Color(0xFF1E6B3D)
private val NOTE = Color(0xFF777777)
private val ACTUAL_TEXT = Color(0xFF2F4A6D)     // 실제로 잔 시각 (그래프의 파란 바탕과 같은 계열)

@Composable
fun ScheduleCard(s: Schedule, onAskTargetWake: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, LINE)
    ) {
        Column(Modifier.padding(14.dp)) {
            // (v7 11/05) 제목 옆 "기준 ○/○ 07:08 기상"은 뺐다 — 위 날짜 선택·분석 첫 줄에 같은 정보가 있다
            Text(s.title, style = MaterialTheme.typography.titleMedium)
            // (v8 최종 11/06) 상태 줄의 "임시 모델" 글자는 뺐다 (개발 확인용). 기록이 적을 때 등 안내가 있을 때만 상자를 보인다
            if (s.notices.isNotEmpty() || s.status.progress != null) {
                Spacer(Modifier.height(8.dp))
                StatusLine(s)
            }

            if (s.isPast) {
                // ── 지난 날 (2026-10-24): 권장 없이 「예상과 실제」 — 모델이 얼마나 맞았는지 비교 ──
                Spacer(Modifier.height(10.dp))
                Section(PRED_BG, PRED_LINE) {
                    Text("예상과 실제", style = MaterialTheme.typography.labelLarge, color = PRED_TEXT, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("예상", style = MaterialTheme.typography.labelMedium, color = NOTE)
                    if (s.model != null) TimesRow(s.model)
                    else Text(s.modelNote, style = MaterialTheme.typography.bodySmall, color = NOTE)
                    Spacer(Modifier.height(10.dp))
                    Text("실제", style = MaterialTheme.typography.labelMedium, color = ACTUAL_TEXT)
                    s.actual?.let { TimesRow(it, ACTUAL_TEXT) }
                    s.actualNote?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = NOTE) }
                    s.diffText?.let {
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Text("차이 · $it", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("권장 시각은 가장 최근 날짜에서만 보여요.", style = MaterialTheme.typography.labelSmall, color = NOTE)
            } else {
            // ── 예상 (2026-10-24 A안: 권장처럼 시각만) ──
            Spacer(Modifier.height(10.dp))
            Section(PRED_BG, PRED_LINE) {
                Text("예상", style = MaterialTheme.typography.labelLarge, color = PRED_TEXT, fontWeight = FontWeight.Bold)
                if (s.model != null) TimesRow(s.model)
                else Text(s.modelNote, style = MaterialTheme.typography.bodySmall, color = NOTE, modifier = Modifier.padding(top = 4.dp))
            }

            // ── 권장 (가장 최근 날짜만) ──
            Spacer(Modifier.height(10.dp))
            Section(REC_BG, REC_LINE) {
                val rec = s.recommended
                when {
                    rec != null -> {
                        // (v7 11/05) 권장 → "07:08에 일어나려면 (7시간 33분 수면)" → 큰 취침 시각 (따로 있던 "권장 수면 ○" 줄은 합침)
                        Text("권장", style = MaterialTheme.typography.labelLarge, color = REC_TEXT, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(2.dp))
                        Text("${rec.targetWakeText}에 일어나려면" + (rec.durationText?.let { " ($it 수면)" } ?: ""),
                            style = MaterialTheme.typography.bodySmall, color = REC_TEXT)
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(rec.bedText, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = REC_TEXT)
                            Text("  전에 취침", style = MaterialTheme.typography.bodyMedium, color = REC_TEXT)
                        }
                        // (v7) 알람 없음 → 평소 기상 기준 안내 / 알람이 평소보다 늦음 → 노란 한 줄
                        rec.basisNote?.let {
                            Spacer(Modifier.height(6.dp))
                            Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF5D7A66))
                        }
                        (rec.shortNote ?: rec.lateNote)?.let {
                            Spacer(Modifier.height(8.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7E6)), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(it, style = MaterialTheme.typography.bodySmall, color = Color(0xFF6B4A00),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                            }
                        }
                    }
                    s.needsTargetWake -> {
                        Text("권장", style = MaterialTheme.typography.labelLarge, color = REC_TEXT, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "몇 시에 일어나야 하나요? 목표 기상을 알려 주면 권장 취침 시각을 계산해 드려요.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = onAskTargetWake,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = REC_TEXT, contentColor = Color.White)
                        ) { Text("목표 기상 입력하기") }
                    }
                    else -> {
                        Text("권장", style = MaterialTheme.typography.labelLarge, color = REC_TEXT, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(s.unavailableText ?: "", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            }
            // 참고 (작게): 내 평소 패턴(기록 요약)
            Text(
                "참고 · 내 평소 패턴  " + (s.habit?.let { "${it.bedText} 취침 → ${it.wakeText} 기상 (${s.habitNote})" } ?: s.habitNote),
                style = MaterialTheme.typography.labelSmall, color = PRED_TEXT
            )
            Text("ⓘ ${s.note}", style = MaterialTheme.typography.labelSmall, color = NOTE)
        }
    }
}

@Composable
private fun StatusLine(s: Schedule) {
    val (bg, fg, bar) = when (s.status.level) {
        ScheduleLevel.LOW -> Triple(Color(0xFFFDF0F0), Color(0xFF8C1D18), Color(0xFFC0443B))
        ScheduleLevel.WARN -> Triple(Color(0xFFFFF7E6), Color(0xFF6B4A00), Color(0xFFD9A21B))
        ScheduleLevel.INFO -> Triple(Color(0xFFF3F5F8), Color(0xFF3A4352), Color(0xFF6B7A90))
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = bg),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            // (2026-10-24) 왜 이렇게 계산됐는지 (채윤 이유 코드 → AnalysisPresenter.limitNotices)
            //  (v8 최종) 모델 이름 줄(s.status.text, "임시 모델")은 화면에 보이지 않는다 — 저장 기록에는 그대로 남음
            val many = s.notices.size > 1
            s.notices.forEach { Text(if (many) "· $it" else it, style = MaterialTheme.typography.bodySmall, color = fg) }
            s.status.progress?.let { p ->
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { p.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(5.dp),
                    color = bar,
                    trackColor = bar.copy(alpha = 0.2f)
                )
            }
        }
    }
}

/** 연한 바탕 + 얇은 테두리 상자 */
@Composable
private fun Section(bg: Color, line: Color, content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = bg),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, line),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) { content() }
    }
}

/** 취침 | 기상 두 칸 (2026-10-24: 이름 줄 없이 시각만 — 권장 상자와 같은 모양) */
@Composable
private fun TimesRow(t: ScheduleTimes, color: Color = Color(0xFF1F2933)) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text("취침", style = MaterialTheme.typography.labelSmall, color = NOTE)
            Text(t.bedText, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        }
        Text("→", fontSize = 17.sp, color = NOTE, modifier = Modifier.padding(horizontal = 6.dp))
        Column(Modifier.weight(1f)) {
            Text("기상", style = MaterialTheme.typography.labelSmall, color = NOTE)
            Text(t.wakeText, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        }
    }
}
