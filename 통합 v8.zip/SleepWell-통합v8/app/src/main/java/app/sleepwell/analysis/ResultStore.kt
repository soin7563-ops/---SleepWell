package app.sleepwell.analysis

import java.io.File

/*
 * 결과 저장·조회 (소빈 · 2026-10-24) — 작업 지시서 Ⅲ-4 "… → 권장시간 산출 → 결과 저장 및 조회"
 *
 * - 「다음 수면 일정」에서 "이 결과 저장"을 누르면, **그때 화면에 보인 그대로** 한 줄 저장한다.
 *   (모델이 나중에 바뀌어도 "그날 앱이 뭐라고 했는지"를 다시 볼 수 있게 계산값이 아니라 보인 글자를 남긴다)
 * - 저장 위치: 앱 전용 폴더(filesDir)의 saved_results.csv. 앱을 껐다 켜도 남는다. 앱을 지우면 같이 지워진다.
 * - (v7 2026-11-05) 같은 날이라도 알람·내 정보·설문을 바꿔 다시 저장하면 **따로** 남긴다 (달력에 점이 하나씩 늘어남).
 *   화면이 똑같은 결과를 두 번 누른 경우만 새것으로 바꾼다. 지난 날짜(예상 vs 실제)도 저장할 수 있다.
 * - (v7) 결과 화면을 다시 그릴 계산 재료는 SavedSnapshot(saved_snapshots/<저장시각>/) 에 따로 둔다.
 * - 새 라이브러리 없이 CSV 로 둔다. 백업·복원·서버 전송은 아직 없음 (채윤 저장 구조가 정해지면 교체 가능).
 * - Android 없이 시험할 수 있도록 File 만 받는다.
 */
data class SavedResult(
    val savedAtMs: Long,
    val source: String,
    val basisMs: Long,
    val basisText: String,
    val modelText: String,
    val recText: String,
    val habitText: String,
    val statusText: String,
    val surveyText: String,
    val sValue: String,
    val cValue: String,
    val pValue: String,
    /** (v7) 분석 화면에서 고른 날짜(그날 아침 기상일, 한국 시간 yyyy-MM-dd) — 달력에 점을 찍는 날 */
    val dayDate: String = "",
    /** (v7) 지난 날짜에서 저장 (예상 vs 실제 화면) */
    val isPast: Boolean = false,
    /** (v7) 지난 날짜: 실제로 잔 시각 + 차이 */
    val actualText: String = "",
    /** (v7) 저장할 때 내 정보 요약 */
    val profileText: String = ""
)

object ResultStore {
    private val HEADER = listOf(
        "savedAtMs", "source", "basisMs", "basisText", "modelText", "recText",
        "habitText", "statusText", "surveyText", "S", "C", "propensity",
        "dayDate", "isPast", "actualText", "profileText"          // (v7) 맨 뒤에 붙임 — 예전 파일은 열 이름으로 읽어서 그대로 열림
    )

    /** 지금 화면(가장 최근 밤)의 결과 → 저장할 한 줄. 일정 카드가 없으면 null */
    fun fromDisplay(
        d: AnalysisDisplay, source: String, surveyText: String?, nowMs: Long = System.currentTimeMillis(),
        profileText: String = ""
    ): SavedResult? {
        val s = d.schedule ?: return null
        val dayDate = d.night?.basisMs?.takeIf { it > 0 }?.let { dateKst(it) } ?: dateKst(d.referenceMs)
        fun pair(t: ScheduleTimes?) = t?.let { "${it.bedText} 취침 → ${it.wakeText} 기상" } ?: "—"
        val rec = s.recommended
        return SavedResult(
            savedAtMs = nowMs,
            source = source,
            basisMs = d.referenceMs,
            basisText = s.basisText,
            modelText = pair(s.model),
            recText = when {
                s.isPast -> ""
                rec != null -> "${rec.bedText} 취침 → ${rec.targetWakeText} 기상" + (rec.durationText?.let { " · 권장 수면 $it" } ?: "")
                s.needsTargetWake -> "목표 기상 없음"
                else -> s.unavailableText ?: "—"
            },
            habitText = pair(s.habit),
            statusText = s.status.text,
            surveyText = surveyText ?: "",
            sValue = d.readings.firstOrNull { it.kind == ReadingKind.S }?.value ?: "",
            cValue = d.readings.firstOrNull { it.kind == ReadingKind.C }?.value ?: "",
            pValue = d.readings.firstOrNull { it.kind == ReadingKind.P }?.value ?: "",
            dayDate = dayDate,
            isPast = s.isPast,
            actualText = if (!s.isPast) "" else (s.actual?.let { pair(it) + (s.diffText?.let { t -> " · $t" } ?: "") } ?: (s.actualNote ?: "")),
            profileText = profileText
        )
    }

    /** epoch ms → 한국 시간 날짜 yyyy-MM-dd */
    fun dateKst(ms: Long): String = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneId.of("Asia/Seoul")).toLocalDate().toString()

    /** 최신 저장이 위로 */
    fun load(file: File): List<SavedResult> {
        if (!file.exists()) return emptyList()
        val rows = try { splitCsv(file.readText(Charsets.UTF_8)) } catch (e: Exception) { return emptyList() }
        if (rows.isEmpty()) return emptyList()
        val h = rows.first()
        fun col(r: List<String>, n: String) = h.indexOf(n).takeIf { it >= 0 }?.let { r.getOrNull(it) } ?: ""
        return rows.drop(1).mapNotNull { r ->
            val saved = col(r, "savedAtMs").toLongOrNull() ?: return@mapNotNull null
            SavedResult(
                saved, col(r, "source"), col(r, "basisMs").toLongOrNull() ?: 0L, col(r, "basisText"),
                col(r, "modelText"), col(r, "recText"), col(r, "habitText"), col(r, "statusText"),
                col(r, "surveyText"), col(r, "S"), col(r, "C"), col(r, "propensity"),
                dayDate = col(r, "dayDate").ifBlank { col(r, "basisMs").toLongOrNull()?.let { dateKst(it) } ?: "" },
                isPast = col(r, "isPast") == "true",
                actualText = col(r, "actualText"),
                profileText = col(r, "profileText")
            )
        }.sortedByDescending { it.savedAtMs }
    }

    fun save(file: File, r: SavedResult): List<SavedResult> = saveReplacing(file, r).first

    /**
     * (v7) 저장하고, 똑같은 결과라서 바꿔 끼운(지운) 이전 저장의 저장 시각 목록도 돌려준다 → 그 계산 재료(SavedSnapshot)도 지우게.
     * "똑같은 결과" = 같은 데이터 · 같은 날 · 같은 화면 종류 · 예상 · 권장 · 실제 · 설문 · 내 정보가 모두 같음
     */
    fun saveReplacing(file: File, r: SavedResult): Pair<List<SavedResult>, List<Long>> {
        val before = load(file)
        fun same(o: SavedResult) = o.source == r.source && o.dayDate == r.dayDate && o.isPast == r.isPast &&
            o.modelText == r.modelText && o.recText == r.recText && o.actualText == r.actualText &&
            o.surveyText == r.surveyText && o.profileText == r.profileText
        val replaced = before.filter(::same).map { it.savedAtMs }
        val all = (before.filterNot(::same) + r).sortedByDescending { it.savedAtMs }
        write(file, all)
        return all to replaced
    }

    fun delete(file: File, savedAtMs: Long): List<SavedResult> {
        val all = load(file).filterNot { it.savedAtMs == savedAtMs }
        write(file, all)
        return all
    }

    private fun write(file: File, all: List<SavedResult>) {
        val sb = StringBuilder(HEADER.joinToString(",")).append('\n')
        all.forEach { r ->
            sb.append(listOf(
                r.savedAtMs.toString(), r.source, r.basisMs.toString(), r.basisText, r.modelText, r.recText,
                r.habitText, r.statusText, r.surveyText, r.sValue, r.cValue, r.pValue,
                r.dayDate, r.isPast.toString(), r.actualText, r.profileText
            ).joinToString(",") { esc(it) }).append('\n')
        }
        // 쓰다가 앱이 꺼져도 기존 파일이 깨지지 않게: 임시 파일에 다 쓴 뒤 바꿔 끼운다
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(sb.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(file)) { file.writeText(sb.toString(), Charsets.UTF_8); tmp.delete() }
    }

    private fun esc(s: String) = if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s

    private fun splitCsv(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>(); val cell = StringBuilder(); var q = false; var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                q && ch == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                ch == '"' -> q = !q
                !q && ch == ',' -> { row += cell.toString(); cell.clear() }
                !q && (ch == '\n' || ch == '\r') -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row += cell.toString(); cell.clear(); rows += row; row = mutableListOf()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row += cell.toString(); rows += row }
        return rows
    }
}
