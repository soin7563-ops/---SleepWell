package app.sleepwell.analysis

import app.sleepwell.health.DisplaySettings
import app.sleepwell.health.DirectInput
import java.text.SimpleDateFormat
import java.util.Locale

/*
 * 4단계 직접 입력: 화면의 글자 입력 → 채윤 파이프라인의 DirectInput 으로 바꾸는 곳. (소빈 · 2026-09-25)
 *
 * 근거 (1순위 md #5)
 *  - "필요한 경우 최근 취침·기상 시각이나 예상 취침·기상 시각 등 기본 정보를 직접 입력"
 *  - cf. "사용자가 입력한 개인 정보(컨디션 상태, 전날 취침 시간 및 기상 시간, 갤럭시 워치 건강정보)를 받아 분석"
 *  - 가능하다면 "내일 몇 시에 일어나야 하는지 / 오늘 몇 시쯤 잘 예정인지" 입력 → 취침·수면시간 계산
 *
 * 계산에 실제로 쓰이는 것 (2026-10-24 갱신)
 *  - 최근 취침~기상(기록 보완): 수면 압력 계산에 반영
 *  - 목표 기상: 권장 엔진이 연결되면 권장 취침 계산에 반영 (지금 폴더에는 엔진 없음 → 화면에 "준비 중")
 *  - 피로도·카페인·낮잠·운동(설문 항목): 계산에 반영 안 됨 — SurveyDay 로 담아 두기만 (개인 보정 학습 후 반영 예정)
 *  - 예정 취침: 화면 칸은 뺐다 (계산에 안 쓰임). 형식 처리는 남겨 둠
 *
 * 시각 형식은 "yyyy-MM-dd HH:mm". (2026-10) 화면에 선택된 표시 시간대(한국 시간/UTC)로 읽는다 —
 * 사용자는 화면에 보이는 시각으로 입력하므로. 기본은 한국 시간이라 기존 동작과 같다.
 */
data class DirectInputForm(
    val bedText: String = "",
    val wakeText: String = "",
    val plannedBedText: String = "",
    val targetWakeText: String = "",
    /** (2026-10-24) 피로도 1~7 — 취침 전 웹 설문과 같은 척도 (이전: 컨디션 1~5, 1 = 피곤) */
    val condition: Int? = null,
    // ── (2026-10-24) 취침 전 설문 항목 (마지막 기록 다음 수면 기준) — 웹 설문·모델 입력(DailySurveyFeatures)과 같은 항목 ──
    val caffeineMgText: String = "",
    val lastCaffeineText: String = "",
    val napMinText: String = "",
    val napEndText: String = "",
    val exerciseMinText: String = "",
    /** none / light / moderate / vigorous (웹 설문 값 그대로). null = 선택 안 함 */
    val exerciseIntensity: String? = null
)

data class ParsedDirectInput(
    /** 입력이 하나도 없으면 null */
    val input: DirectInput?,
    val errors: List<String>,
    /** (2026-10-24) 설문 항목 (설문 항목을 하나도 안 넣으면 null). featureValues() 로 모델 입력 이름이 된다 */
    val survey: SurveyDay? = null
) {
    val ok: Boolean get() = errors.isEmpty()
}

object DirectInputParser {

    const val PATTERN = "yyyy-MM-dd HH:mm"
    private const val MAX_SLEEP_MS = 16 * 3_600_000L
    /** 파이프라인 계산 범위(기준 시각 이전 7일). 채윤-소빈 합의값 */
    const val WINDOW_MS = 7 * 24 * 3_600_000L

    /**
     * 이 파일로 직접 입력을 반영할 수 있는 마지막 기상 시각(이 시각 **전**까지).
     * 기상 시각이 기준이 되면 그 이전 7일을 계산하는데, 그 안에 업로드 기록이 하나도 없으면
     * 기록 없는 날을 전부 '깨어 있음'으로 계산하게 되어(S 가 1.0 에 붙음) 파이프라인이 거부한다.
     */
    fun latestWakeAllowed(lastRecordEndMs: Long): Long = lastRecordEndMs + WINDOW_MS

    /**
     * (2026-09-25 추가) 이 시각 **이후**에 깬 수면만 반영된다.
     * 기상이 마지막 기록보다 앞이면 기준 시각은 마지막 기록 그대로이고, 계산 범위는 그 이전 7일뿐이라
     * 더 오래된 입력은 파이프라인에서 조용히 무시된다(결과는 그대로인데 화면엔 "반영됨"으로 나오던 문제).
     */
    fun earliestWakeAllowed(lastRecordEndMs: Long): Long = lastRecordEndMs - WINDOW_MS

    private fun format() = SimpleDateFormat(PATTERN, Locale.US).apply {
        timeZone = DisplaySettings.zone.tz
        isLenient = false          // 2026-09-31 같은 날짜를 조용히 10/1 로 넘기지 않게
    }

    fun toText(ms: Long): String = format().format(java.util.Date(ms))

    /** "7:30" / "07:30" */
    private val CLOCK = Regex("""^(\d{1,2}):(\d{2})$""")

    /** 목표 기상은 기준 시각에서 이만큼은 떨어져야 한다 (아침 7:07 에 깬 기록 + 알람 07:30 → 23분 뒤가 아니라 다음 날 07:30) */
    const val MIN_WAKE_GAP_MS = 3 * 3_600_000L

    /** base(+minGapMs) 다음에 처음 오는 h:mm (표시 시간대). */
    fun nextOccurrence(base: Long, h: Int, mi: Int, minGapMs: Long = 0L): Long {
        val c = java.util.Calendar.getInstance(DisplaySettings.zone.tz).apply {
            timeInMillis = base
            set(java.util.Calendar.HOUR_OF_DAY, h); set(java.util.Calendar.MINUTE, mi)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        while (c.timeInMillis <= base + minGapMs) c.add(java.util.Calendar.DAY_OF_MONTH, 1)
        return c.timeInMillis
    }

    fun parse(form: DirectInputForm, lastRecordEndMs: Long? = null): ParsedDirectInput {
        val errors = mutableListOf<String>()

        fun read(label: String, text: String): Long? {
            val t = text.trim()
            if (t.isEmpty()) return null
            return try {
                val pos = java.text.ParsePosition(0)
                val d = format().parse(t, pos)
                if (d == null || pos.index != t.length) { errors += "$label: \"$t\" 형식이 맞지 않아요 (예: 2026-09-15 23:30" + (if (label == "목표 기상" || label == "예정 취침") ", 또는 시각만 07:30" else "") + ")"; null }
                else d.time
            } catch (e: Exception) {
                errors += "$label: \"$t\" 형식이 맞지 않아요 (예: 2026-09-15 23:30" + (if (label == "목표 기상" || label == "예정 취침") ", 또는 시각만 07:30" else "") + ")"; null
            }
        }

        val bed = read("최근 취침", form.bedText)
        val wake = read("최근 기상", form.wakeText)

        // (2026-10-24) 목표 기상·예정 취침은 "07:30"처럼 시각만 써도 된다.
        // 기준 = 계산 기준 시각(마지막 기록, 직접 입력한 최근 기상이 더 늦으면 그 기상) — 폰 날짜가 아니다.
        // 과거 기록 파일도 분석하므로, 폰 기준 "내일"을 쓰면 데이터와 날짜가 어긋난다.
        // 그 기준 시각 **다음에 처음 오는** 그 시각으로 이해한다. 날짜까지 쓰면 그대로 쓴다.
        val base = listOfNotNull(lastRecordEndMs, wake).maxOrNull() ?: System.currentTimeMillis()
        fun readPlan(label: String, text: String, minGapMs: Long): Long? {
            val t = text.trim()
            CLOCK.matchEntire(t)?.let { m ->
                val h = m.groupValues[1].toInt(); val mi = m.groupValues[2].toInt()
                if (h > 23 || mi > 59) { errors += "$label: \"$t\" 는 없는 시각이에요"; return null }
                return nextOccurrence(base, h, mi, minGapMs)
            }
            return read(label, t)
        }
        val plannedBed = readPlan("예정 취침", form.plannedBedText, 0L)
        val targetWake = readPlan("목표 기상", form.targetWakeText, MIN_WAKE_GAP_MS)

        if ((bed == null) != (wake == null) && errors.isEmpty()) {
            errors += "최근 취침과 기상 시각은 둘 다 입력해야 수면으로 반영돼요."
        }
        if (bed != null && wake != null) {
            if (wake <= bed) errors += "최근 기상 시각이 취침 시각보다 늦어야 해요."
            else if (wake - bed > MAX_SLEEP_MS) errors += "수면이 16시간을 넘어요. 날짜를 확인해 주세요."
        }
        if (bed != null && wake != null && wake > bed && lastRecordEndMs != null &&
            wake >= latestWakeAllowed(lastRecordEndMs)) {
            errors += "업로드한 기록의 마지막이 ${toText(lastRecordEndMs)} 이라서, 기상 시각은 " +
                    "${toText(latestWakeAllowed(lastRecordEndMs))} 이전이어야 반영돼요. " +
                    "(그 사이 기록이 없으면 전부 '깨어 있음'으로 계산돼 결과가 틀어져요)"
        }
        if (bed != null && wake != null && wake > bed && lastRecordEndMs != null &&
            wake <= earliestWakeAllowed(lastRecordEndMs)) {
            errors += "계산 범위는 업로드 기록의 마지막(${toText(lastRecordEndMs)}) 이전 7일이라서, 기상 시각은 " +
                    "${toText(earliestWakeAllowed(lastRecordEndMs))} 이후여야 반영돼요."
        }
        if (form.condition != null && form.condition !in 1..7) errors += "피로도는 1~7 중에서 골라 주세요."

        // ── 설문 항목 (2026-10-24) — 숫자·시각 형식만 확인. 모델 반영은 개인 보정 학습 후 ──
        fun num(label: String, text: String, max: Double): Double? {
            val t = text.trim(); if (t.isEmpty()) return null
            val v = t.toDoubleOrNull()
            if (v == null || v < 0 || v > max) { errors += "$label: \"$t\" 는 0~${max.toInt()} 사이 숫자로 써 주세요."; return null }
            return v
        }
        fun clock(label: String, text: String): String? {
            val t = text.trim(); if (t.isEmpty()) return null
            val m = CLOCK.matchEntire(t)
            if (m == null || m.groupValues[1].toInt() > 23 || m.groupValues[2].toInt() > 59) { errors += "$label: \"$t\" 는 07:30 처럼 써 주세요."; return null }
            return String.format(Locale.US, "%02d:%02d", m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }
        val caf = num("카페인(mg)", form.caffeineMgText, 2000.0)
        val lastCaf = clock("마지막 카페인", form.lastCaffeineText)
        val nap = num("낮잠(분)", form.napMinText, 600.0)
        val napEnd = clock("낮잠 끝난 시각", form.napEndText)
        val ex = num("운동(분)", form.exerciseMinText, 600.0)
        val anySurvey = listOf(caf, lastCaf, nap, napEnd, ex, form.exerciseIntensity, form.condition).any { it != null } ||
                form.targetWakeText.isNotBlank()
        // 설문 날짜 = 기준 시각 − 6시간의 날짜 (웹 설문의 "예측 기준 날짜"와 같은 뜻)
        val survey = if (!anySurvey) null else SurveyDay(
            participant = "me", date = SurveyCsv.surveyDateFor(base),
            caffeineUsed = caf?.let { it > 0 }, caffeineMg = caf, lastCaffeine = lastCaf,
            napMinutes = nap, napEnd = napEnd, exerciseMinutes = ex, exerciseEnd = null,
            exerciseIntensity = form.exerciseIntensity, fatigue = form.condition,
            steps = null, heartRate = null,
            alarmTime = CLOCK.matchEntire(form.targetWakeText.trim())?.let { m ->       // 웹 설문처럼 "07:30" 두 자리로
                String.format(Locale.US, "%02d:%02d", m.groupValues[1].toInt(), m.groupValues[2].toInt())
            },
            firstCommitment = null, examTomorrow = false, alcohol = false, illness = false
        )

        val any = listOf(bed, wake, plannedBed, targetWake).any { it != null }
        val input = if (!any) null else DirectInput(
            sleepStartMs = bed,
            sleepEndMs = wake,
            targetWakeMs = targetWake,
            plannedBedMs = plannedBed
        )
        return ParsedDirectInput(input, errors, survey)
    }
}
