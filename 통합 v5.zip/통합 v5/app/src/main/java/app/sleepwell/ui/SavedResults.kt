package app.sleepwell.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.sleepwell.analysis.ResultStore
import app.sleepwell.analysis.SavedResult
import app.sleepwell.analysis.SurveyDay
import app.sleepwell.analysis.SurveyStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * 저장 기록 화면 (소빈 · 2026-10-24) — 작업 지시서 Ⅲ-4 "결과 저장 및 조회"
 *  - 「다음 수면 일정」에서 "이 결과 저장"을 누른 결과를, 그때 화면에 보인 글자 그대로 최신순으로 보여준다.
 *  - 저장 파일: 앱 전용 폴더 saved_results.csv (ResultStore). 폰 안에만 있고 서버로 보내지 않는다.
 */

/** 분석 화면과 저장 기록 화면이 같은 파일을 쓰도록 한 곳에서 정한다 */
fun savedResultsFile(context: android.content.Context) = File(context.filesDir, "saved_results.csv")

/** (2026-10-24) 실제 컨디션 입력에서 쌓인 설문 (웹 설문 CSV 내보내기와 같은 형식) */
fun surveyLogFile(context: android.content.Context) = File(context.filesDir, "survey_log.csv")

@Composable
fun SavedResultsScreen() {
    val context = LocalContext.current
    val file = remember { savedResultsFile(context) }
    var items by remember { mutableStateOf(ResultStore.load(file)) }
    val surveyFile = remember { surveyLogFile(context) }
    var surveys by remember { mutableStateOf(SurveyStore.load(surveyFile)) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    // 설문 기록 내보내기: 사용자가 고른 곳(다운로드 폴더 등)에 CSV 로 쓴다 → 서윤 언니 학습 코드에 그대로 넣을 수 있는 형식
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        exportMessage = try {
            context.contentResolver.openOutputStream(uri)?.use { it.write(SurveyStore.toCsv(surveys).toByteArray(Charsets.UTF_8)) }
            "내보냈어요 (${surveys.size}줄)."
        } catch (e: Exception) { "내보내지 못했어요: ${e.message}" }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("저장 기록", style = MaterialTheme.typography.headlineSmall)
        Text(
            "「다음 수면 일정」에서 저장한 결과예요. 그때 화면에 보인 그대로 남아 있어요. (이 폰 안에만 저장)",
            style = MaterialTheme.typography.bodySmall, color = Color(0xFF777777)
        )
        if (items.isEmpty()) {
            Spacer(Modifier.height(24.dp))
            Text("아직 저장한 결과가 없어요. 수면 분석에서 「다음 수면 일정」 아래 \"이 결과 저장\"을 눌러 주세요.", style = MaterialTheme.typography.bodyMedium)
        }
        items.forEach { r ->
            Spacer(Modifier.height(12.dp))
            SavedCard(r, onDelete = { items = ResultStore.delete(file, r.savedAtMs) })
        }

        // ── 설문 기록 (2026-10-24) — 실제 컨디션 입력이 날짜별로 쌓인 것 ──
        Spacer(Modifier.height(28.dp))
        Text("설문 기록", style = MaterialTheme.typography.titleMedium)
        Text(
            "「실제 컨디션 입력」에서 반영할 때마다 날짜별로 쌓여요 (같은 날은 마지막 입력). 지금은 계산에 쓰이지 않고, 개인 보정 학습 데이터로 모아요. (이 폰 안에만 저장)",
            style = MaterialTheme.typography.bodySmall, color = Color(0xFF777777)
        )
        if (surveys.isEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("아직 쌓인 설문이 없어요.", style = MaterialTheme.typography.bodyMedium)
        } else {
            val real = surveys.count { it.participant != "Test" }
            Text("쌓인 기록: 내 기록 ${real}일" + (surveys.size - real).takeIf { it > 0 }?.let { " · 합성(Test) ${it}일" }.orEmpty(),
                style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            OutlinedButton(
                onClick = { exportMessage = null; exporter.launch("sleepwell_survey_log.csv") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("설문 기록 CSV 내보내기") }
            exportMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777)) }
            surveys.forEach { d ->
                Spacer(Modifier.height(8.dp))
                SurveyRow(d, onDelete = { surveys = SurveyStore.delete(surveyFile, d.participant, d.date) })
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun SavedCard(r: SavedResult, onDelete: () -> Unit) {
    val savedText = SimpleDateFormat("M/d(E) HH:mm", Locale.KOREA).apply { timeZone = UiZone.current.tz }.format(Date(r.savedAtMs))
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E5EA))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.basisText.replace("기준 ", "") + " 기준 일정", style = MaterialTheme.typography.titleSmall)
                    Text("$savedText 저장 · 데이터: ${r.source}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777777))
                }
                TextButton(onClick = onDelete) { Text("삭제") }
            }
            Spacer(Modifier.height(6.dp))
            Line("권장", r.recText, Color(0xFF1E6B3D))
            Line("모델 예상", r.modelText, Color(0xFF4A5363))
            Line("평소 패턴", r.habitText + " (최근 7일 중간값)", Color(0xFF4A5363))
            Line("상태", "수면 압력 ${r.sValue} · 일주기 리듬 ${r.cValue} · 잠들기 쉬운 정도 ${r.pValue}", Color(0xFF4A5363))
            if (r.surveyText.isNotBlank()) Line("설문", r.surveyText, Color(0xFF4A5363))
            Text(r.statusText, style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A5A00))
        }
    }
}

@Composable
private fun Line(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = color, modifier = Modifier.weight(0.28f))
        Text(value, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(0.72f))
    }
}

@Composable
private fun SurveyRow(d: SurveyDay, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E5EA))
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(d.date.substring(5).replace('-', '/') + if (d.participant == "Test") "  (합성)" else "",
                    style = MaterialTheme.typography.labelLarge)
                Text(d.summary(), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = onDelete) { Text("삭제") }
        }
    }
}
