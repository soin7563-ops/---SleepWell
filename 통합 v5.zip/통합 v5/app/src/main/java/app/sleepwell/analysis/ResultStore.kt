package app.sleepwell.analysis

import java.io.File

/*
 * 결과 저장·조회 (소빈 · 2026-10-24) — 작업 지시서 Ⅲ-4 "… → 권장시간 산출 → 결과 저장 및 조회"
 *
 * - 「다음 수면 일정」에서 "이 결과 저장"을 누르면, **그때 화면에 보인 그대로** 한 줄 저장한다.
 *   (모델이 나중에 바뀌어도 "그날 앱이 뭐라고 했는지"를 다시 볼 수 있게 계산값이 아니라 보인 글자를 남긴다)
 * - 저장 위치: 앱 전용 폴더(filesDir)의 saved_results.csv. 앱을 껐다 켜도 남는다. 앱을 지우면 같이 지워진다.
 * - 같은 데이터(파일 이름) + 같은 기준 시각이면 새로 저장한 것으로 바꾼다 (목표 기상을 바꿔 다시 저장한 경우).
 * - 새 라이브러리 없이 CSV 로 둔다. 백업·복원·서버 전송은 아직 없음 (채윤 저장 구조가 정해지면 교체 가능).
 * - Android 없이 시험할 수 있도록 File 만 받는다.
 */
data class SavedResult(
    val savedAtMs: Long,
    val source: String,
    val basisMs: Long,
    val basisText: String,
    val modelText: String,
    val recText: String,
    val habitText: String,
    val statusText: String,
    val surveyText: String,
    val sValue: String,
    val cValue: String,
    val pValue: String
)

object ResultStore {
    private val HEADER = listOf(
        "savedAtMs", "source", "basisMs", "basisText", "modelText", "recText",
        "habitText", "statusText", "surveyText", "S", "C", "propensity"
    )

    /** 지금 화면(가장 최근 밤)의 결과 → 저장할 한 줄. 일정 카드가 없으면 null */
    fun fromDisplay(d: AnalysisDisplay, source: String, surveyText: String?, nowMs: Long = System.currentTimeMillis()): SavedResult? {
        val s = d.schedule ?: return null
        if (s.isPast) return null
        fun pair(t: ScheduleTimes?) = t?.let { "${it.bedText} 취침 → ${it.wakeText} 기상" } ?: "—"
        val rec = s.recommended
        return SavedResult(
            savedAtMs = nowMs,
            source = source,
            basisMs = d.referenceMs,
            basisText = s.basisText,
            modelText = pair(s.model),
            recText = when {
                rec != null -> "${rec.targetWakeText} 기상 목표 → ${rec.bedText} 전에 취침" + (rec.sleepText?.let { " · $it" } ?: "")
                s.needsTargetWake -> "목표 기상 없음"
                else -> s.unavailableText ?: "—"
            },
            habitText = pair(s.habit),
            statusText = s.status.text,
            surveyText = surveyText ?: "",
            sValue = d.readings.firstOrNull { it.kind == ReadingKind.S }?.value ?: "",
            cValue = d.readings.firstOrNull { it.kind == ReadingKind.C }?.value ?: "",
            pValue = d.readings.firstOrNull { it.kind == ReadingKind.P }?.value ?: ""
        )
    }

    /** 최신 저장이 위로 */
    fun load(file: File): List<SavedResult> {
        if (!file.exists()) return emptyList()
        val rows = try { splitCsv(file.readText(Charsets.UTF_8)) } catch (e: Exception) { return emptyList() }
        if (rows.isEmpty()) return emptyList()
        val h = rows.first()
        fun col(r: List<String>, n: String) = h.indexOf(n).takeIf { it >= 0 }?.let { r.getOrNull(it) } ?: ""
        return rows.drop(1).mapNotNull { r ->
            val saved = col(r, "savedAtMs").toLongOrNull() ?: return@mapNotNull null
            SavedResult(
                saved, col(r, "source"), col(r, "basisMs").toLongOrNull() ?: 0L, col(r, "basisText"),
                col(r, "modelText"), col(r, "recText"), col(r, "habitText"), col(r, "statusText"),
                col(r, "surveyText"), col(r, "S"), col(r, "C"), col(r, "propensity")
            )
        }.sortedByDescending { it.savedAtMs }
    }

    fun save(file: File, r: SavedResult): List<SavedResult> {
        val kept = load(file).filterNot { it.source == r.source && it.basisMs == r.basisMs }
        val all = (kept + r).sortedByDescending { it.savedAtMs }
        write(file, all)
        return all
    }

    fun delete(file: File, savedAtMs: Long): List<SavedResult> {
        val all = load(file).filterNot { it.savedAtMs == savedAtMs }
        write(file, all)
        return all
    }

    private fun write(file: File, all: List<SavedResult>) {
        val sb = StringBuilder(HEADER.joinToString(",")).append('\n')
        all.forEach { r ->
            sb.append(listOf(
                r.savedAtMs.toString(), r.source, r.basisMs.toString(), r.basisText, r.modelText, r.recText,
                r.habitText, r.statusText, r.surveyText, r.sValue, r.cValue, r.pValue
            ).joinToString(",") { esc(it) }).append('\n')
        }
        // 쓰다가 앱이 꺼져도 기존 파일이 깨지지 않게: 임시 파일에 다 쓴 뒤 바꿔 끼운다
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(sb.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(file)) { file.writeText(sb.toString(), Charsets.UTF_8); tmp.delete() }
    }

    private fun esc(s: String) = if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s

    private fun splitCsv(text: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>(); val cell = StringBuilder(); var q = false; var i = 0
        while (i < text.length) {
            val ch = text[i]
            when {
                q && ch == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                ch == '"' -> q = !q
                !q && ch == ',' -> { row += cell.toString(); cell.clear() }
                !q && (ch == '\n' || ch == '\r') -> {
                    if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row += cell.toString(); cell.clear(); rows += row; row = mutableListOf()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row += cell.toString(); rows += row }
        return rows
    }
}
